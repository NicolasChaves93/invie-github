package com.porvenir.comunes;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Comunes.java En esta clase se van a ubicar los metodos o procedimientos que
 * van a usar en conjunto el ejb y war
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 09/10/2019
 */
public class Comunes {

	// Parametro para mapear los eventos de la clase
	private final static Logger logger= LoggerFactory.getLogger(Comunes.class);


	private Comunes() {
		
	}

	/**
	 * Busca los EJB por JNDI
	 * 
	 * @param name:
	 *            Nombre del EJB en el servidor
	 * @return Object: retorna la instancia de un EJB
	 */
	public static Object getEJB(String name) {
		InitialContext ctx = null;
		Object custService = null;

		try {
			ctx = new InitialContext();
			custService = ctx.lookup(name);
		} catch (NamingException e) {
			logger.info("Error --> Al inicializar el EJB");
		}

		return custService;
	}

	/**
	 * Metodo que convierte una estructura JSON a Objeto
	 * 
	 * @param objJson
	 *            Estructura JSON
	 * @param className
	 *            Nombre de la clase que convoca al metodo
	 * @throws IOException
	 *             Problemas al transformar de JSON a Object
	 * @return Object
	 * 
	 */
	public static <T extends Object> T convertJSONTOObject(String objJson, Class<T> className) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		T newObject = null;
		
		if(objJson!=null){
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		newObject = mapper.readValue(objJson, className);}
		else{
			logger.info("Error --> al convertir la estructura a objeto");
		}
		return newObject;
	}

	/**
	 * Metodo que convierte un objeto a estructura JSON
	 * 
	 * @param obb
	 *            Parametro donde se recibe el objeto
	 * @return String contenido la estructura JSON
	 * @throws JsonProcessingException
	 *             Problemas al transformar de Object a JSON
	 */
	public static String convertObjectTOJSON(Object obb) throws JsonProcessingException {
		ObjectMapper mapper = null;
		String converJSON =null;

		mapper = new ObjectMapper();
		if(obb!=null){
			converJSON = mapper.writeValueAsString(obb);
		}else{
			logger.info("Error --> al convertir el objeto a la estructura");
		}
		return converJSON;
	}

	/**
	 * Metodo que me genera las cabeceras del header y el cuerpo de respuesta
	 * 
	 * @param request
	 *            Parametro donde se recibe de la cabecera el valor de rqUID
	 * @param status
	 *            respuesta de la peticion Http
	 * @param resp
	 *            Objeto de respuesta
	 * @return El response que va a mostrar el servicio
	 */
	public static Response headerResponse(String request, Status status, Object resp) {
		Map<String, String> respuesta = new HashMap<String, String>();
		
		Response.ResponseBuilder response = null;

		// Adiciona codigo de respuesta http y el objeto respuesta
		response = Response.status(status);
		response.type(MediaType.APPLICATION_JSON);
		response.entity(resp);

		// Adicionar cabeceras al Response
		respuesta.put("rqUID", request);

		for (Map.Entry<String, String> entry : respuesta.entrySet()) {
			response.header(entry.getKey(), entry.getValue());
		}

		return response.build();
	}
}
