package com.porvenir.comunes;

/**
 * ConstantesService.java En esta clase se van a referenciar los valores al archivo properties 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 09/10/2019
 */
public final class ConstantesService {
	/**
	 * Contructor
	 */
	private ConstantesService(){
	}

	/** codigo para respuesta exitoso */
	public final static int COD_RESPUESTA_200 = 200;
	
	/** Referencia constante para mensaje del codigo exitoso */
	public final static String COD_RESPUESTA_200_MESSAGE = "ok.200.message";
	
	/** codigo para respuesta vacia*/
	public final static int COD_ERROR_204 = 204;
	
	/** Referencia constante para respuesta vacia 204 */
	public final static String COD_ERROR_204_MESSAGE = "error.204.message";
	
	// Constantes de error
	/** codigo para errores negocio */
	public final static int COD_ERROR_406 = 406;
	
	/** Referencia constante para mensaje de error de negocio 406 */
	public final static String COD_ERROR_406_MESSAGE = "error.406.message";
	
	/** codigo para errores internos */
	public final static int COD_ERROR_500 = 500;
	
	/** Referencia constante para mensaje de error interno */
	public final static String COD_ERROR_500_MESSAGE = "error.500.message";
	
	/** Referencia constante para el codigo de negocio 100 */
	public final static int COD_ERROR_100 = 100;
	
	/** Referencia constante para mensaje de error de negocio 100 */
	public final static String COD_ERROR_100_MESSAGE = "error.100.message";
	
	/** Referencia constante para el codigo de negocio 101 */
	public final static int COD_ERROR_101 = 101;
	
	/** Referencia constante para mensaje de error de negocio 101 */
	public final static String COD_ERROR_101_MESSAGE = "error.101.message";
	
	/** Referencia constante para el codigo de negocio 103 */
	public final static int COD_ERROR_103 = 103;
	
	/** Referencia constante para mensaje de error de negocio 103 */
	public final static String COD_ERROR_103_MESSAGE = "error.103.message";
	
	/** Referencia constante para el codigo de negocio 104 */
	public final static int COD_ERROR_104 = 104;
	
	/** Referencia constante para mensaje de error de negocio 104 */
	public final static String COD_ERROR_104_MESSAGE = "error.104.message";
	
	/** Referencia constante para el codigo de negocio 105 */
	public final static int COD_ERROR_105 = 105;
	
	/** Referencia constante para mensaje de error de negocio 105 */
	public final static String COD_ERROR_105_MESSAGE = "error.105.message";
	
	/** Referencia constante para el codigo de negocio 106 */
	public final static int COD_ERROR_106 = 106;
	
	/** Referencia constante para mensaje de error de negocio 106 */
	public final static String COD_ERROR_106_MESSAGE = "error.106.message";
	
	/** Referencia constante para error de conversion objeto a JSON*/
	public final static String LOG_MESSAGE_ERROR_CONVERT_JSON = "log.error.json";
	
	// Cabeceras del servicio
	/** Constante de la cabecera clientID */
	public final static String X_CLIENT_ID = "clientID";
	
	/** Constante de la cabecera rqUID */
	public final static String X_RQU_ID = "rqUID";
	
	/** Constante de la cabecera serviceID */
	public final static String X_SERVICE_ID = "serviceID";
	
	/** Constante de la cabecera userTransaction */
	public final static String X_USER_TRANSACTION = "userTransaction";
	
	/** Constante que referencia el servicio de EJB para busqueda de propiedades*/
	public final static String EJB_PROPERTIES="java:comp/env/ejb/PropiedadesServicesFacade";
	
	/** Key que identifica en el properties el SERVICE_ID*/
	public final static String SERVICE_ID_NAME="SERVICE_ID";
	
	/** Informacion de contacto para la firma Swagger*/
	public final static String CONTACT_SWAGGER = "BPO01S24V01.swagger.contact";

	/** Descripcion de contacto para la firma Swagger*/
	public final static String CONTACT_DESCRIP_SWAGGER = "BPO01S24V01.swagger.contact.descrip";

	/** Informacion de los terminos y condiciones para la firma Swagger*/
	public final static String TERMS_SWAGGER = "BPO01S24V01.swagger.terminos";

	/** licencia para la firma Swagger*/
	public final static String LIC_SWAGGER = "BPO01S24V01.swagger.licencia";

	/** URL de la licencia Porvenir*/
	public final static String LIC_URL_SWAGGER = "BPO01S24V01.swagger.licencia.url";

	/** URL externa para mas informacion del proyecto Swagger*/
	public final static String EXTERNAL_URL_SWAGGER = "BPO01S24V01.swagger.external.url";

	/** Descripcion de la URL externa del proyecto Swagger*/
	public final static String EXTERNAL_URL_DESC_SWAGGER = "BPO01S24V01.swagger.external.descrip";

	/** Version actual de la firma Swagger*/
	public final static String VERSION_SWAGGER_BPO01S24V01 = "BPO01S24V01.swagger.version";

	/** informacion del Schema del servicio para Swagger*/
	public final static String SCHEMES_SWAGGER_BPO01S24V01 = "BPO01S24V01.swagger.schemes";

	/** informacion del Host para la firma Swagger*/
	public final static String HOST_SWAGGER_BPO01S24V01 = "BPO01S24V01.swagger.host";

	/** informacion del path para la firma Swagger*/
	public final static String BASEPATH_SWAGGER_BPO01S24V01 = "BPO01S24V01.swagger.path.base";

	/** informacion del paquete para la firma Swagger*/
	public final static String PACKAGE_SWAGGER_BPO01S24V01 = "BPO01S24V01.swagger.package";

	/** Titulo del servicio Swagger*/
	public final static String TITLE_SWAGGER_BPO01S24V01 = "BPO01S24V01.swagger.title";
	
	/** Cabeceras obligatorias del servicio*/
	public final static String HEADERS_REQUEST_REQUIRED = "BPO01S24V01.headers.required";
	
	/** id del tipo de pago*/
	public final static String TIPO_PAGO_ID = "RETIRO_PROGRAMADO";
}
