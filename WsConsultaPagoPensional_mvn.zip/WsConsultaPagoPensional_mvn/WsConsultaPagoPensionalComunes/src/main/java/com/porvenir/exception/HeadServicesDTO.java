package com.porvenir.exception;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Clase que contiene la informacion de los valores del header
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 18/10/2019
 */
public class HeadServicesDTO { 

	@JsonProperty("header_name")
	private String headerName;

	@JsonProperty("required")
	private Boolean required;

	@JsonProperty("min")
	private Integer min;

	@JsonProperty("max")
	private Integer max;

	@JsonProperty("enum")
	private String[] enumData;

	public String getHeaderName() {
		return headerName;
	}

	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}

	public Boolean getRequired() {
		return required;
	}

	public void setRequired(Boolean required) {
		this.required = required;
	}

	public Integer getMin() {
		return min;
	}

	public void setMin(Integer min) {
		this.min = min;
	}

	public Integer getMax() {
		return max;
	}

	public void setMax(Integer max) {
		this.max = max;
	}

	public String[] getEnumData() {
		return enumData;
	}

	public void setEnumData(String[] enumData) {
		this.enumData = enumData;
	}

}
