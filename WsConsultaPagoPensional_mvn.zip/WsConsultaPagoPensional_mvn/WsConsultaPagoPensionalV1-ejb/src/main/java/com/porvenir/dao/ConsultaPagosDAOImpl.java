package com.porvenir.dao;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.dto.RespConsultaPagoPensional;
import com.porvenir.dto.RespDatosBasicos;
import com.porvenir.dto.RespDatosPago;

/**
 * Implementacion de la interfaz SMS
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 30/10/2019
 */
@Stateless
public class ConsultaPagosDAOImpl implements ConsultaPagosDAO{ 
	
	@PersistenceContext(unitName= "DbporvePension-PU")
	EntityManager em;

	@Override
	public RespConsultaPagoPensional consultaDatosBasicos(String tipoIdentificacion, String numIdentificacion)
	{
		RespConsultaPagoPensional respConsultaPagoPensional = new RespConsultaPagoPensional();
		RespDatosBasicos respDatosBasicos = new RespDatosBasicos();
		try
		{
			Query q1 = em.createNativeQuery("SELECT TIPO_IDENTIFICACION_ID " +
							"FROM MGENERAL.GEN_TIPO_IDENTIFICACION " + 
							"WHERE ABREVIATURA = ?tipoId");
			q1.setParameter("tipoId", tipoIdentificacion);
			
			BigDecimal resultQ1 = (BigDecimal) q1.getSingleResult();
			int tipoIdResult = resultQ1.intValue();
			
			Query q2 = em.createNativeQuery(
					"select *" +
							"  from (select p.tipo_identificacion," + 
							"               p.numero_identificacion," + 
							"               s.solicitud_id," + 
							"               s.cuenta_afiliado," + 
							"               s.tipo_reclamacion_id," + 
							"               tr.nombre_reclamacion," + 
							"               s.codigo_radicacion_rec," + 
							"               s.estado_reclamacion_id," + 
							"               e.nombre_estado_rec," + 
							"               s.fecha_creacion" + 
							"          from MPENGES.spg_persona            p," + 
							"               MPENGES.spg_beneficiario       b," + 
							"               MPENGES.spg_solicitud          s," + 
							"               MPENGES.spg_tipo_reclamacion   tr," + 
							"               MPENGES.spg_estado_reclamacion e" + 
							"         where p.persona_id = b.persona_id" + 
							"           and tr.tipo_reclamacion_id = s.tipo_reclamacion_id" + 
							"           and b.solicitud_id = s.solicitud_id" + 
							"           and e.estado_reclamacion_id = s.estado_reclamacion_id" + 
							"			and e.activo ='S'" +
							"           and p.numero_identificacion = ?numId" + 
							"           and p.tipo_identificacion = ?tipoId" + 
							"         order by s.fecha_creacion desc)" + 
							" where rownum = 1");
			
			q2.setParameter("numId", numIdentificacion);
			q2.setParameter("tipoId", tipoIdResult);
			Object[] result = (Object[]) q2.getSingleResult();
			
			if(result == null || result.length == 0)
			{
				return null;
			}
			
			respDatosBasicos.setTipoIdentificacion(tipoIdentificacion);
			respDatosBasicos.setNumIdentificacion((String) result[1]);
			respDatosBasicos.setSolicitudId(((BigDecimal) result[2]).intValue());
			respDatosBasicos.setCuentaAfiliado(((BigDecimal) result[3]).intValue());
			respDatosBasicos.setTipoReclamacionId(((BigDecimal) result[4]).intValue());
			respDatosBasicos.setNombreReclamacion((String) result[5]);
			respDatosBasicos.setCodigoRadicacionRec((String) result[6]);
			respDatosBasicos.setEstadoReclamacionId(((BigDecimal) result[7]).intValue());
			respDatosBasicos.setNombreEstadoRec((String) result[8]);
			Date fechaCreacion = (Date) result[9];
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
			respDatosBasicos.setFechaCreacion(dateFormat.format(fechaCreacion));
			respConsultaPagoPensional.setDatosBasicos(respDatosBasicos);
		}
		catch(NoResultException e)
		{
			return null;
		}
		return respConsultaPagoPensional;
	}
	
	@Override
	public RespConsultaPagoPensional consultaListaPagos(RespConsultaPagoPensional respConsultaPagoPensional) 
	{
		try
		{
			Query q1 = em.createNativeQuery("select pa.fecha_pago,\n" +
					"       pa.pago_id,\n" + 
					"       pa.periodo,\n" + 
					"       c.cuenta_por_pagar_id,\n" + 
					"       pa.valor_pesos_total\n" + 
					"  from spg_cuenta_por_pagar c, spg_pago pa\n" + 
					" where c.solicitud_id = ?numSolicitud\n" + 
					"   and c.tipo_pago_id = ?tipoPagoId\n" + 
					"   and c.cuenta_por_pagar_id = pa.cuenta_por_pagar_id\n" + 
					"   and (pa.fecha_pago =\n" + 
					"       (select min(p.fecha_pago)\n" + 
					"           from spg_pago p\n" + 
					"          where pa.cuenta_por_pagar_id = p.cuenta_por_pagar_id) or\n" + 
					"       pa.fecha_pago =\n" + 
					"       (select max(p.fecha_pago)\n" + 
					"           from spg_pago p\n" + 
					"          where pa.cuenta_por_pagar_id = p.cuenta_por_pagar_id))\n" + 
					" order by pa.fecha_pago");
			q1.setParameter("numSolicitud", respConsultaPagoPensional.getDatosBasicos().getSolicitudId());
			q1.setParameter("tipoPagoId", ConstantesService.TIPO_PAGO_ID);
			
			List<Object[]> resultList = (List<Object[]>) q1.getResultList();
			
			if(resultList == null)
			{
				return null;
			}
			if(resultList.isEmpty())
			{
				respConsultaPagoPensional.setListaPagos(new ArrayList<RespDatosPago>());
			}
			else
			{
				ArrayList<RespDatosPago> listPagos = new ArrayList<RespDatosPago>();
				for(Object[] o : resultList)
				{
					RespDatosPago respDatosPago = new RespDatosPago();
					if(o[0] != null)
					{
						Date fechaPago = (Date) o[0];
						DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
						
						respDatosPago.setFechaPago(dateFormat.format(fechaPago));
					}
					else
					{
						respDatosPago.setFechaPago("");
					}
					respDatosPago.setPagoId(((BigDecimal) o[1]).intValue());
					respDatosPago.setPeriodo(((BigDecimal) o[2]).intValue());
					respDatosPago.setCuentaPorPagarId(((BigDecimal) o[3]).intValue());
					respDatosPago.setValorPesosTotal(((BigDecimal) o[4]).intValue());
					
					listPagos.add(respDatosPago);
				}
				respConsultaPagoPensional.setListaPagos(listPagos);
			}
		}
		catch(NoResultException e)
		{
			return null;
		}
		return respConsultaPagoPensional;
	}
	
}
