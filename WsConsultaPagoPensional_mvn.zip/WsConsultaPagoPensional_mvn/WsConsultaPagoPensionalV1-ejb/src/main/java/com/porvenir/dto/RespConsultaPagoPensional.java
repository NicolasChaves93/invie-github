package com.porvenir.dto;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class RespConsultaPagoPensional 
{
	private RespDatosBasicos datosBasicos;
	private ArrayList<RespDatosPago> listaPagos;
	private RespStatus status;
	
	public RespDatosBasicos getDatosBasicos() {
		return datosBasicos;
	}
	public void setDatosBasicos(RespDatosBasicos datosBasicos) {
		this.datosBasicos = datosBasicos;
	}
	public ArrayList<RespDatosPago> getListaPagos() {
		return listaPagos;
	}
	public void setListaPagos(ArrayList<RespDatosPago> listaPagos) {
		this.listaPagos = listaPagos;
	}
	public RespStatus getStatus() {
		return status;
	}
	public void setStatus(RespStatus status) {
		this.status = status;
	}
	
}
