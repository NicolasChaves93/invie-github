package com.porvenir.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class RespDatosBasicos 
{
	@JsonProperty("tipoIdentificacion")
	@ApiModelProperty(value = "Tipo de identificacion del afiliado", required = true)
	private String tipoIdentificacion;

	@JsonProperty("numIdentificacion")
	@ApiModelProperty(dataType = "string",value = "Numero de identificacion del afiliado", required = true)
	private String numIdentificacion;
	
	@JsonProperty("solicitudId")
	@ApiModelProperty(dataType = "Integer",value = "Codigo identificador de solicitud", required = true)
	private int solicitudId;
	
	@JsonProperty("cuentaAfiliado")
	@ApiModelProperty(dataType = "Integer",value = "Numero de cuenta del afiliado", required = true)
	private int cuentaAfiliado;
	
	@JsonProperty("tipoReclamacionId")
	@ApiModelProperty(dataType = "Integer",value = "Tipo de reclamacion pensional", required = true)
	private int tipoReclamacionId;
	
	@JsonProperty("nombreReclamacion")
	@ApiModelProperty(dataType = "string",value = "Nombre del tipo de reclamacion", required = true)
	private String nombreReclamacion;
	
	@JsonProperty("codigoRadicacionRec")
	@ApiModelProperty(dataType = "string",value = "Codigo identificador de radicacion de la reclamacion", required = true)
	private String codigoRadicacionRec;
	
	@JsonProperty("estadoReclamacionId")
	@ApiModelProperty(dataType = "Integer",value = "Codigo identificador del estado de la reclamacion", required = true)
	private int estadoReclamacionId;
	
	@JsonProperty("nombreEstadoRec")
	@ApiModelProperty(dataType = "string",value = "Nombre del estado de la reclamacion", required = true)
	private String nombreEstadoRec;
	
	@JsonProperty("fechaCreacion")
	@ApiModelProperty(dataType = "string",value = "Fecha de creación de la solicitud", required = true)
	private String fechaCreacion;

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumIdentificacion() {
		return numIdentificacion;
	}

	public void setNumIdentificacion(String numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}

	public int getSolicitudId() {
		return solicitudId;
	}

	public void setSolicitudId(int solicitudId) {
		this.solicitudId = solicitudId;
	}

	public int getCuentaAfiliado() {
		return cuentaAfiliado;
	}

	public void setCuentaAfiliado(int cuentaAfiliado) {
		this.cuentaAfiliado = cuentaAfiliado;
	}

	public int getTipoReclamacionId() {
		return tipoReclamacionId;
	}

	public void setTipoReclamacionId(int tipoReclamacionId) {
		this.tipoReclamacionId = tipoReclamacionId;
	}

	public String getNombreReclamacion() {
		return nombreReclamacion;
	}

	public void setNombreReclamacion(String nombreReclamacion) {
		this.nombreReclamacion = nombreReclamacion;
	}

	public String getCodigoRadicacionRec() {
		return codigoRadicacionRec;
	}

	public void setCodigoRadicacionRec(String codigoRadicacionRec) {
		this.codigoRadicacionRec = codigoRadicacionRec;
	}

	public int getEstadoReclamacionId() {
		return estadoReclamacionId;
	}

	public void setEstadoReclamacionId(int estadoReclamacionId) {
		this.estadoReclamacionId = estadoReclamacionId;
	}

	public String getNombreEstadoRec() {
		return nombreEstadoRec;
	}

	public void setNombreEstadoRec(String nombreEstadoRec) {
		this.nombreEstadoRec = nombreEstadoRec;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	
}
