package com.porvenir.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class RespDatosPago 
{
	@JsonProperty("fechaPago")
	@ApiModelProperty(dataType = "string",value = "Fecha del pago", required = true)
	private String fechaPago;
	
	@JsonProperty("pagoId")
	@ApiModelProperty(dataType = "Integer",value = "Codigo identificador del pago", required = true)
	private int pagoId;
	
	@JsonProperty("periodo")
	@ApiModelProperty(dataType = "Integer",value = "Periodo de pago o liquidacion", required = true)
	private int periodo;
	
	@JsonProperty("cuentaPorPagarId")
	@ApiModelProperty(dataType = "Integer",value = "Codigo identificador de la cuenta por pagar", required = true)
	private int cuentaPorPagarId;
	
	@JsonProperty("valorPesosTotal")
	@ApiModelProperty(dataType = "Integer",value = "Valor del pago en pesos", required = true)
	private int valorPesosTotal;

	public String getFechaPago() {
		return fechaPago;
	}

	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}

	public int getPagoId() {
		return pagoId;
	}

	public void setPagoId(int pagoId) {
		this.pagoId = pagoId;
	}

	public int getPeriodo() {
		return periodo;
	}

	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}

	public int getCuentaPorPagarId() {
		return cuentaPorPagarId;
	}

	public void setCuentaPorPagarId(int cuentaPorPagarId) {
		this.cuentaPorPagarId = cuentaPorPagarId;
	}

	public int getValorPesosTotal() {
		return valorPesosTotal;
	}

	public void setValorPesosTotal(int valorPesosTotal) {
		this.valorPesosTotal = valorPesosTotal;
	}
	
}
