package com.porvenir.facade;

import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dao.ConsultaPagosDAO;
import com.porvenir.dto.ReqConsultaPagoPensional;
import com.porvenir.dto.RespConsultaPagoPensional;
import com.porvenir.exception.BusinessException;
import com.porvenir.validate.EnumTipoDocumento;

/**
 * Session Bean implementation class SmsFacade
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@Stateless(name = "ConsultaPagoFacade", mappedName = "ejb/ConsultaPagoFacade")
public class ConsultaPagoFacade implements ConsultaPagoFacadeLocal {

	@EJB
	private ConsultaPagosDAO consultaPagosDAO;

	@Override
	public RespConsultaPagoPensional consultaPagos(ReqConsultaPagoPensional reqConsultaPagoPensional, Map<String, String> headerRequest) throws Exception, BusinessException
	{
		LogsController logger;
		logger = LogsController.getLogs();
		SearchProperties.destroyInstance();
		SearchProperties search = SearchProperties.getInstance();
		RespConsultaPagoPensional respConsultaPagoPensional = new RespConsultaPagoPensional();
		
		if(!validarDocumento(reqConsultaPagoPensional.getTipoIdentificacion()))
		{
			logger.logWarning(ConstantesService.COD_ERROR_103_MESSAGE, headerRequest, ConsultaPagoFacade.class);
			throw new BusinessException(ConstantesService.COD_ERROR_103,
					search.searchParam(ConstantesService.COD_ERROR_103_MESSAGE));
		}
		
		try 
		{
			logger.logInfo("3", "Enviando datos", headerRequest, ConsultaPagoFacade.class);
			
			respConsultaPagoPensional = consultaPagosDAO.consultaDatosBasicos
					(reqConsultaPagoPensional.getTipoIdentificacion(), reqConsultaPagoPensional.getNumIdentificacion());
			
			if(respConsultaPagoPensional!= null)
			{
				respConsultaPagoPensional = consultaPagosDAO.consultaListaPagos(respConsultaPagoPensional);
			}
			headerRequest = null;
			LogsController.destroyLog();
			logger = null;
			reqConsultaPagoPensional = null;
			return respConsultaPagoPensional;
		}
		catch (Exception e) 
		{
			logger.logWarning("Error en las consultas a la base de datos: " + e.toString(), headerRequest, ConsultaPagoFacade.class, e);
			throw new Exception();
		}
	}
	
	private boolean validarDocumento(String valorAValidar)
	{
		for(EnumTipoDocumento a : EnumTipoDocumento.values())
		{
			if(valorAValidar.equals(a.toString()))
			{
				return true;
			}
		}
		return false;
	}

}
