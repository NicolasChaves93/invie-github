package com.porvenir.facade;

import java.util.Map;

import javax.ejb.Local;

import com.porvenir.dto.ReqConsultaPagoPensional;
import com.porvenir.dto.RespConsultaPagoPensional;
import com.porvenir.exception.BusinessException;

/**
 * Interfaz EJB para el servicio de envio de SMS
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@Local
public interface ConsultaPagoFacadeLocal {
	public RespConsultaPagoPensional consultaPagos(ReqConsultaPagoPensional reqConsultaPagoPensional,Map<String, String> headerRequest) throws Exception, BusinessException;

}
