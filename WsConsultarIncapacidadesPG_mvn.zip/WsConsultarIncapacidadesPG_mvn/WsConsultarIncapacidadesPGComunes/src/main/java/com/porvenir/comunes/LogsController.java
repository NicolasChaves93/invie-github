package com.porvenir.comunes;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;

/**
 * LogsController.java Clase que va a contener los tipos de logs que se van a
 * manejar en el EJB
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 09/10/2019
 */
public class LogsController { 
	
	
	private static LogsController logs = null;

	/**
	 * Constructor
	 */
	private LogsController() {
		Logger logger = LoggerFactory.getLogger(LogsController.class);			
		logger.info("Inicializando LogsController");
	}

	/**
	 * Metodo para inicializar la clase
	 * @return LogsController
	 */
	public static LogsController getLogs() {
		if (logs == null) {
			logs = new LogsController();
		}

		return logs;
	}
	
	public static void destroyLog(){
		logs = null;
		Logger logger = LoggerFactory.getLogger(LogsController.class);
		logger.info("Destruyendo LogsController");
	}
	
	public  void reloadConfigure(){
		Logger logger = LoggerFactory.getLogger(LogsController.class);	
		LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
		context.reset();
		JoranConfigurator configurator = new JoranConfigurator();
		configurator.setContext(context);
		try {
			configurator.doConfigure(this.getClass().getResourceAsStream("/logback.xml"));
		} catch (JoranException e) {
			logger.warn("Problemas al recargar la configuración", e);
		}
		
	}

	/**
	 * Method to generate Info logs
	 *@param order Numero secuencia
	 * @param message
	 *            Parametro con informacion del evento que sucedio
	 * @param headers
	 *            Contiene las cabeceras del servicio
	 * @param className
	 *            Nombre de la clase que utiliza el metodo
	 */
	public void logInfo(String order, String message, Map<String, String> headers, Class<?> className) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {		
			logMessage.append(messageLog(headers));
		}
		logMessage.append(order).append(": ").append(message);
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.info(logMessage.toString());
	}

	/**
	 * Method to generate Debug logs
	 * @param message Mensaje
	 * @param headers Cabecera Http
	 * @param className Nombre clase
	 * @param tramaMethod Objeto
	 */
	public void logDebug(String message, Map<String, String> headers, Class<?> className, Object tramaMethod) {
		String tramaJSON = null;
		if (tramaMethod instanceof String) {
			tramaJSON = tramaMethod.toString();
		} else {
			try {
				tramaJSON = Comunes.convertObjectTOJSON(tramaMethod);
			} catch (JsonProcessingException ex) {
				logError(ConstantesService.LOG_MESSAGE_ERROR_CONVERT_JSON, headers, this.getClass(), ex.getMessage());
			}
		}
		StringBuilder logMessage = new StringBuilder(500);

		if (headers != null) {
			logMessage.append(messageLog(headers));
		}

		logMessage.append("Mensaje [").append(message).append(":").append(tramaJSON).append("]");
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.debug(logMessage.toString());
	}

	/**
	 * Method to generate Debug logs
	 * @param order Numero secuencia
	 * @param message Mensaje
	 * @param headers Cabecera Http
	 * @param className Nombre clase
	 * @param tramaMethod Objeto
	 */
	public void logDebug(String order, String message, Map<String, String> headers, Class<?> className,
			Object tramaMethod) {
		
		// Trama request or response de la peticion
		String tramaJSON = null;

		if (tramaMethod instanceof String) {
			tramaJSON = tramaMethod.toString();
		} else {
			try {
				tramaJSON = Comunes.convertObjectTOJSON(tramaMethod);
			} catch (JsonProcessingException ex) {
				logError(ConstantesService.LOG_MESSAGE_ERROR_CONVERT_JSON, headers, this.getClass(), ex.getMessage());
			}
		}
		StringBuilder logMessage = new StringBuilder(500);

		if (headers != null) {
			logMessage.append(messageLog(headers));
		}
		logMessage.append(order);
		logMessage.append(": ");
		logMessage.append("Mensaje [").append(message).append(";").append(tramaJSON).append("]");
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.debug(logMessage.toString());

	}

	/**
	 * Method to generate Error logs
	 *
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 * @param msjException Mensaje de excepcion
	 */
	public void logError(String message, Map<String, String> headers, Class<?> className, String msjException) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}
		
		// Mensaje de error
		logMessage.append(message).append("; errorMessage").append(msjException);
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.error(logMessage.toString());
	}

	/**
	 *  Method to generate Error logs
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 * @param ex Objeto Excepecion
	 */
	public void logError(String message, Map<String, String> headers, Class<?> className, Exception ex) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}
		
		// Mensaje de error
		logMessage.append(message).append("; errorMessage-> ").append(ex.toString());
		Logger logger = LoggerFactory.getLogger(className);
		logger.error(logMessage.toString(), ex);
	}

	/**
	 * Method to generate warn logs
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 * @param msjException Mensaje excepcion
	 */
	public void logWarning(String message, Map<String, String> headers, Class<?> className, String msjException) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}
		logMessage.append(message).append("; errorMessage").append(msjException);
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.warn(logMessage.toString());
	}

	/**
	 * Method to generate Warn logs
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 */
	public void logWarning(String message, Map<String, String> headers, Class<?> className) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}

		// Descripcion del mensaje Warning
		logMessage.append(message);
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.warn(logMessage.toString());
	}

	/**
	 * Method to generate Warn logs
     * @param order Numero de secuencia
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 */
	public void logWarning(String order, String message, Map<String, String> headers, Class<?> className) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}

		// Descripcion del mensaje Warning
		logMessage.append(order);
		logMessage.append(": ");
		logMessage.append(message);

		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.warn(logMessage.toString());
		//

	}

	/**
	 * Method to generate Warn logs
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 * @param ex Excepcion
	 */
	public void logWarning(String message, Map<String, String> headers, Class<?> className, Exception ex) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}

		// Descripcion del mensaje Warning
		logMessage.append(message.concat("->"));
		logMessage.append(ex.getMessage());
		Logger logger = LoggerFactory.getLogger(className.getName());

		logger.warn(logMessage.toString());
	}

	/**
	 * Method to generate Warn logs
	 * @param order Numero de secuencia
	 * @param message Mensaje
	 * @param headers Cabeceras Http
	 * @param className Nombre clase
	 * @param ex Excepcion
	 */
	public void logWarning(String order, String message, Map<String, String> headers, Class<?> className,
			Exception ex) {
		StringBuilder logMessage = new StringBuilder(500);
		if (headers != null) {
			logMessage.append(messageLog(headers));
		}

		// Descripcion del mensaje Warning
		logMessage.append(order);
		logMessage.append(": ");
		logMessage.append(message.concat("->"));
		logMessage.append(ex.getMessage());
		Logger logger = LoggerFactory.getLogger(className.getName());
		logger.warn(logMessage.toString());

	}

	/**
	 * Method to process head of all the logs
	 * @param headers Cabeceras Http
	 * @return StringBuilder
	 */
	public StringBuilder headProcess(Map<String, String> headers) {
		
		// Identificador de la entidad que consume el servicio
		String clientID = "";

		if (headers.get(ConstantesService.X_CLIENT_ID.toLowerCase()) != null) {
			clientID = headers.get(ConstantesService.X_CLIENT_ID.toLowerCase());
		} else {
			clientID = headers.get(ConstantesService.X_CLIENT_ID);
		}

		// Identificador unico del mensaje
		String rqUID = "";
		if (headers.get(ConstantesService.X_RQU_ID.toLowerCase()) != null) {
			rqUID = headers.get(ConstantesService.X_RQU_ID.toLowerCase());
		} else {
			rqUID = headers.get(ConstantesService.X_RQU_ID);
		}

		// Identificador del servicio y operacion
		String serviceID = "";
		if (headers.get(ConstantesService.X_SERVICE_ID.toLowerCase()) != null) {
			serviceID = headers.get(ConstantesService.X_SERVICE_ID.toLowerCase());
		} else {
			serviceID = headers.get(ConstantesService.X_SERVICE_ID);
		}

		// Corresponde al nombre de usuario que hizo el Login en la App
		String userTransaction = "";
		if (headers.get(ConstantesService.X_USER_TRANSACTION.toLowerCase()) != null) {
			userTransaction = headers.get(ConstantesService.X_USER_TRANSACTION.toLowerCase());
		} else {
			userTransaction = headers.get(ConstantesService.X_USER_TRANSACTION);
		}

		boolean isPresentHeaders = clientID != null && rqUID != null && serviceID != null && userTransaction != null;
		StringBuilder logMessage = new StringBuilder(500);

		if (isPresentHeaders) {
			logMessage.append("Header [ ").append(clientID).append(";").append(rqUID).append(";").append(serviceID)
					.append(";").append(userTransaction).append(" ] ");

		}
		return logMessage;

	}
	
	private StringBuilder messageLog(Map<String, String> headers){
		StringBuilder logMessage = new StringBuilder(500);
		String service = headers.get("serviceID");
		String idTransation = headers.get("transactionId");
		
		logMessage.append("[ ").append(service).append(" ] ");
		logMessage.append("[ ").append(idTransation).append(" ] ");
		logMessage.append(headProcess(headers));
		
		return logMessage;
	}

}
