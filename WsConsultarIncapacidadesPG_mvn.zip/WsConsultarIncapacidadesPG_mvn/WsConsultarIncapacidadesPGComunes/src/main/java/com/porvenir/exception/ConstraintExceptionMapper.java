package com.porvenir.exception;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.SearchProperties;

@Provider
public class ConstraintExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

	@Context
	private HttpServletRequest request;

	public Response toResponse(ConstraintViolationException exception) { 
		// TODO Auto-generated method stub
		RespException resp = new RespException();
		RespStatusExcepcion status = new RespStatusExcepcion();
		SearchProperties searchProperties = SearchProperties.getInstance();
		Response response;
		Logger logger = LoggerFactory.getLogger(ConstraintExceptionMapper.class);

		status.setStatusCode(ConstantesService.COD_ERROR_106);
		List<String> listMessagesResp = new ArrayList<String>();
		exception.getConstraintViolations().forEach(element -> 
		{
			StringBuilder messageCompleted = new StringBuilder();
			String campo = element.getPropertyPath().toString();
			messageCompleted.append(campo.substring(campo.lastIndexOf(".") + 1)  ).append("->").append(element.getMessage());
			listMessagesResp.add(messageCompleted.toString());
		});
		
		logger.info(searchProperties.searchParam(ConstantesService.COD_ERROR_106_MESSAGE) + listMessagesResp.toString());
		status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_106_MESSAGE) + listMessagesResp.toString());
		resp.setStatus(status);
		response = Comunes.headerResponse(request.getHeader("rqUID"), Status.NOT_ACCEPTABLE, resp);

		return response;
	}

}
