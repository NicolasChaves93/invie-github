package com.porvenir.exception;

/**
 * Objeto para las exepciones del servicio
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 18/10/2019
 */
public class RespException 
{
	private RespStatusExcepcion status;

	public RespStatusExcepcion getStatus() {
		return status;
	}

	public void setStatus(RespStatusExcepcion status) {
		this.status = status;
	} 
	
}
