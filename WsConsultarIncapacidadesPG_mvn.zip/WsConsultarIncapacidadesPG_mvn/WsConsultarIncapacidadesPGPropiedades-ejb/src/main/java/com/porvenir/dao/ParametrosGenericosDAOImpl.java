package com.porvenir.dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import com.porvenir.model.ParametrosGenericos;

/**
 * DAO que representa la entidad PropiedadesServicios
 * @author Harry Hurtado Arango POR09786
 * @since 30-10-2019 
 *
 */
@Stateless
public class ParametrosGenericosDAOImpl extends AbstractDAO<ParametrosGenericos, Integer> implements ParametrosGenericosDAO
{ 
	@PersistenceContext(unitName= "DbParamIncap-PU")
	private EntityManager em;
	private final static Integer ID_MODULO_GEN=40500;

	public ParametrosGenericosDAOImpl() 
	{
		super(ParametrosGenericos.class);
	}

	@Override
	protected EntityManager getEntityManager() 
	{
		return em;
	}

	/**
	 * Busca todos los parametros por service id
	 * @param String serviceId
	 * @return List<PropiedadesServicios>
	 */
	@Override
	public List<ParametrosGenericos> getAllPropServiciosByServiceId(String serviceId) 
	{
		TypedQuery<ParametrosGenericos> query=em.createNamedQuery("PropiedadesServicios.findAllByServiceId",ParametrosGenericos.class);
		query.setParameter("idServicio","%".concat(serviceId).concat("%") );
		query.setParameter("idModulo", ID_MODULO_GEN);
		serviceId = null;
		return query.getResultList();
	}
}
