package com.porvenir.dao;

import java.util.ArrayList;

import javax.ejb.Local;

import com.porvenir.dto.RespConsultarIncapacidadesPG;
import com.porvenir.dto.RespDatosBasicos;
import com.porvenir.dto.RespDatosPago;
import com.porvenir.exception.BusinessException;

/**
 * Interfaz que me representa la insercion de datos
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 30/10/2019
 */
@Local
public interface ConsultarIncapacidadesDAO 
{ 
	public RespDatosBasicos datosBasicosIncapacidades(String tipoIdentificacion, String numIdentificacion) throws BusinessException;
	
	public ArrayList<RespDatosPago> listaPagosIncapacidades(int solicitudId);
}
