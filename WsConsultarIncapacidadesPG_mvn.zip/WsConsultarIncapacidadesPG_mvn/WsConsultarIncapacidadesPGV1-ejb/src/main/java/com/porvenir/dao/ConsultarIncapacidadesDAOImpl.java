package com.porvenir.dao;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dto.RespDatosBasicos;
import com.porvenir.dto.RespDatosPago;
import com.porvenir.exception.BusinessException;
import com.porvenir.facade.ConsultarIncapacidadesFacade;

/**
 * Implementacion de la interfaz SMS
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 30/10/2019
 */
@Stateless
public class ConsultarIncapacidadesDAOImpl implements ConsultarIncapacidadesDAO{ 
	
	@PersistenceContext(unitName= "DbporveIncap-PU")
	EntityManager em;

	@Override
	public RespDatosBasicos datosBasicosIncapacidades(String tipoIdentificacion, String numIdentificacion) throws BusinessException 
	{
		LogsController logger;
		logger = LogsController.getLogs();
		SearchProperties search = SearchProperties.getInstance();
		try
		{
			RespDatosBasicos datosBasicos = new RespDatosBasicos();
			Date fechaHoy = new Date(Calendar.getInstance().getTimeInMillis());
			BigDecimal numId = new BigDecimal(numIdentificacion);
			DateFormat formatoFechaDatos = new SimpleDateFormat("yyyy-MM-dd");
			
			Query q1 = em.createNativeQuery(
					"select S.SOLICITUD_ID,\n" +
							"       S.CUENTA_ID,\n" + 
							"       S.TIPO_SOLICITUD,\n" + 
							"       S.TUTELA,\n" + 
							"       S.FECHA_TUTELA,\n" + 
							"       S.FECHA_RADICACION,\n" + 
							"       A.NUMERO_IDENTIFICACION,\n" + 
							"       A.TIPO_IDENTIFICACION,\n" + 
							"       a.primer_nombre,\n" + 
							"       a.segundo_nombre,\n" + 
							"       a.primer_apellido,\n" + 
							"       a.segundo_apellido\n" + 
							"  from mincap.inc_solicitud s, cta_cuenta c, cta_afiliado a\n" + 
							" where s.cuenta_id = c.cuenta_id\n" + 
							"   and c.afiliado_fondo_id = a.afiliado_fondo_id\n" + 
							"   AND TRUNC(S.FECHA_RADICACION) >= TO_DATE(?fechaRad, 'dd/mm/yyyy')\n" + 
							"   AND S.TIPO_SOLICITUD = ?tipoSol\n" + 
							"   and a.tipo_identificacion = ?tipoId\n" + 
							"   and a.numero_identificacion = ?numId");
			
			q1.setParameter("numId", numId);
			q1.setParameter("tipoId", tipoIdentificacion);
			//Seteo parametros base de datos
			q1.setParameter("fechaRad", search.searchParam(ConstantesService.FEC_RADICACION));
			q1.setParameter("tipoSol", search.searchParam(ConstantesService.SOLICITUD_DATOS));
			Object[] r = (Object[]) q1.getSingleResult();
			
			datosBasicos.setSolicitudId(((BigDecimal) r[0]).intValue());
			datosBasicos.setCuentaId(((BigDecimal) r[1]).intValue());
			datosBasicos.setTipoSolicitud(r[2]!=null?(String) r[2]: "");
			datosBasicos.setTutela(r[3]!=null?(String) r[3]: "");
			datosBasicos.setFechaTutela(r[4]!=null?formatoFechaDatos.format((Date) r[4]):"");
			datosBasicos.setFechaRadicacion(r[5]!=null?formatoFechaDatos.format((Date) r[5]):"");
			datosBasicos.setNumIdentificacion(((BigDecimal) r[6]).toString());
			datosBasicos.setTipoIdentificacion(r[7]!=null?(String) r[7]: "");
			String pNombre = r[8]!=null? (String)r[8]:"";
			String sNombre = r[9]!=null? (String)r[9]:"";
			String pApellido = r[10]!=null? (String)r[10]:"";
			String sApellido = r[11]!=null? (String)r[11]:"";
			
			String nombre = pNombre + " " + sNombre + " " + pApellido + " " + sApellido;
			nombre = nombre.trim();
			nombre = nombre.replace("  ", " ");
			nombre = nombre.replace("  ", " ");
			datosBasicos.setNombreAfiliado(nombre);
			
			DateFormat dateFormat = new SimpleDateFormat("dd-MMMM-yyyy");
			String fechaString = (dateFormat.format(fechaHoy));
			
			String[] split = fechaString.split("-");
			
			datosBasicos.setDia(Integer.valueOf(split[0]));
			datosBasicos.setMes(split[1]);
			datosBasicos.setAnio(Integer.valueOf(split[2]));
			
			return datosBasicos;
		}
		catch(NoResultException e)
		{
			logger.logWarning("X", "no se obtuvieron resultados en la lista de pagos", null, ConsultarIncapacidadesDAOImpl.class);
			return null;
		}
		catch(Exception e)
		{
			logger.logWarning("X", "Excepcion Datos Basicos: " + e.toString(), null, ConsultarIncapacidadesDAOImpl.class);
			throw new BusinessException(ConstantesService.COD_ERROR_104,
					search.searchParam(ConstantesService.COD_ERROR_104_MESSAGE));
		}
	}
	
	@Override
	public ArrayList<RespDatosPago> listaPagosIncapacidades(int solicitudId) 
	{
		LogsController logger;
		logger = LogsController.getLogs();
		SearchProperties search = SearchProperties.getInstance();
		try
		{
			ArrayList<RespDatosPago> listDatosPagos = new ArrayList<RespDatosPago>();
			DateFormat formatoFechaDatos = new SimpleDateFormat("yyyy-MM-dd");
			
			Query q2 = em.createNativeQuery(
					"SELECT TRUNC(PR.FECHA_INICIO) AS FECHA_INICIO,\n" +
							"       TRUNC(PR.FECHA_FIN) AS FECHA_FIN,\n" + 
							"       PR.DIAS_INCAPACIDAD AS DIAS_INCAPACIDAD,\n" + 
							"       CXC.VALOR_PAGADO_ASEGURADORA AS VALOR,\n" + 
							"       cxc.beneficiario_pago_id,\n" + 
							"       (CASE\n" + 
							"         WHEN CLA.TIPO_INGRESO = 'TUTELA_I' THEN\n" + 
							"          'Incapacidad por tutela'\n" + 
							"         WHEN CLA.TIPO_INGRESO = 'TUTELA_P' THEN\n" + 
							"          'Prórroga por tutela'\n" + 
							"         WHEN CLA.TIPO_INGRESO = 'INICIAL' THEN\n" + 
							"          'Inicial'\n" + 
							"         WHEN CLA.TIPO_INGRESO = 'PRORROGA' THEN\n" + 
							"          'Prórroga'\n" + 
							"         WHEN CLA.TIPO_INGRESO = 'AJUSTE' THEN\n" + 
							"          'Ajuste'\n" + 
							"       END) AS CONCEPTO_PAGO,\n" + 
							"       CXC.ESTADO_PAGO_SP\n" + 
							"  FROM MPENGES.SPG_CUENTA_POR_COBRAR  CXC,\n" + 
							"       MINCAP.INC_CASO_LIQ_APROBACION CLA,\n" + 
							"       MINCAP.INC_SOLICITUD           S,\n" + 
							"       MINCAP.INC_PRORROGA            PR,\n" + 
							"       MCUENTAS.CTA_CUENTA            C\n" + 
							"\n" + 
							" WHERE PR.PRORROGA_ID = CXC.INCAPACIDAD_PRORROGA_ID\n" + 
							"   AND PR.PRORROGA_ID = CLA.PRORROGA_ID\n" + 
							"   AND CLA.CASO_LIQ_APROBACION_ID = CXC.CASO_LIQ_APROBACION_ID\n" + 
							"   AND S.SOLICITUD_ID = PR.SOLICITUD_ID\n" + 
							"   AND C.CUENTA_ID = S.CUENTA_ID\n" + 
							"   AND S.TIPO_SOLICITUD = ?tipoSol\n" + 
							"   and s.solicitud_id = ?numSolicitud\n" + 
							"   AND CXC.ESTADO_PAGO_SP IN\n" + 
							"       (" + search.searchParam(ConstantesService.ESTADO_PAGO_SP) + ")\n" + 
							"\n" + 
							" ORDER BY PR.FECHA_INICIO DESC");
			
			q2.setParameter("numSolicitud", solicitudId);
			//Seteo parametros base de datos
			q2.setParameter("tipoSol", search.searchParam(ConstantesService.SOLICITUD_PAGOS));
			logger.logInfo("X", "Se va a ejecutar el query de la lista de pagos", null, ConsultarIncapacidadesDAOImpl.class);
			List<Object[]> r = (List<Object[]>) q2.getResultList();
			for(Object[] o : r)
			{
				RespDatosPago datosPago = new RespDatosPago();
				datosPago.setFechaInicio(o[0]!=null?((Date) o[0]).toString():"");
				datosPago.setFechaFin(o[1]!=null?formatoFechaDatos.format((Date) o[1]):"");
				datosPago.setDiasIncapacidad(o[2]!=null?((BigDecimal) o[2]).intValue():0);
				datosPago.setValor(o[3]!=null?((BigDecimal) o[3]).doubleValue():0);
				int idBeneficiario = o[4]!=null?((BigDecimal) o[4]).intValue():0;
				datosPago.setConceptoPago(o[5]!=null?(String) o[5]: "");
				datosPago.setEstadoPagoSP(o[6]!=null?(String) o[6]: "");
				
				String nombreBeneficiario = obtenerNombreBeneficiario(idBeneficiario);
				datosPago.setNombreBeneficiario(nombreBeneficiario.trim());
				
				listDatosPagos.add(datosPago);
			}
			return listDatosPagos;
		}
		catch(NoResultException e)
		{
			logger.logWarning("X", "no se obtuvieron resultados en la lista de pagos", null, ConsultarIncapacidadesDAOImpl.class);
			ArrayList<RespDatosPago> listDatosPagos = new ArrayList<RespDatosPago>();
			return listDatosPagos;
		}
		catch (Exception e) 
		{
			logger.logWarning("X", "Excepcion Lista de Pagos: " + e.toString(), null, ConsultarIncapacidadesDAOImpl.class);
			return null;
		}
	}
	
	private String obtenerNombreBeneficiario(int idBeneficiario)
	{
		LogsController logger;
		logger = LogsController.getLogs();
		try
		{
			Query q2 = em.createNativeQuery("SELECT NVL(NVL(P.PRIMER_NOMBRE, A.PRIMER_NOMBRE), P.RAZON_SOCIAL),\n" +
							"       NVL(P.SEGUNDO_NOMBRE, A.SEGUNDO_NOMBRE),\n" + 
							"       NVL(P.PRIMER_APELLIDO, A.PRIMER_APELLIDO),\n" + 
							"       NVL(P.SEGUNDO_APELLIDO, A.SEGUNDO_APELLIDO)\n" + 
							"  FROM MPENGES.SPG_BENEFICIARIO B,\n" + 
							"       MPENGES.SPG_PERSONA      P,\n" + 
							"       MCUENTAS.CTA_AFILIADO    A\n" + 
							" WHERE P.AFILIADO_FONDO_ID = A.AFILIADO_FONDO_ID(+)\n" + 
							"   AND B.PERSONA_ID = P.PERSONA_ID\n" + 
							"   AND B.BENEFICIARIO_ID = ?idBeneficiario");
			
			q2.setParameter("idBeneficiario", idBeneficiario);
			Object[] r = (Object[]) q2.getSingleResult();
			String pNombre = r[0]!=null? (String)r[0]:"";
			String sNombre = r[1]!=null? (String)r[1]:"";
			String pApellido = r[2]!=null? (String)r[2]:"";
			String sApellido = r[3]!=null? (String)r[3]:"";
			
			String nombre = pNombre + " " + sNombre + " " + pApellido + " " + sApellido; 
			nombre = nombre.trim();
			nombre = nombre.replace("  ", " ");
			nombre = nombre.replace("  ", " ");
			return nombre;
		}
		catch(NoResultException e)
		{
			logger.logWarning("X", "no se obtuvieron resultados en el nombre del beneficiario", null, ConsultarIncapacidadesDAOImpl.class);
			return "";
		}
		catch (Exception e) 
		{
			logger.logWarning("X", "Excepcion al obtener el nombre del beneficiario: " + e.toString(), null, ConsultarIncapacidadesDAOImpl.class);
			return "";
		}
	}
}
