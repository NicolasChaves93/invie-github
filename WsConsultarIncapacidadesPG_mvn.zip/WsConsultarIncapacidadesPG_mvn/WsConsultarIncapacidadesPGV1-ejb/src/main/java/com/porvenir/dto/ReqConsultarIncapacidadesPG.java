package com.porvenir.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class ReqConsultarIncapacidadesPG 
{
	@Valid
	@JsonProperty("tipoIdentificacion")
	@Size(min = 2, max = 5, message="Tamaño del texto invalido")
	@ApiModelProperty(value = "Tipo de identificacion del afiliado", required = true)
	@NotNull
	private String tipoIdentificacion;

	@Valid
	@JsonProperty("numIdentificacion")
	@ApiModelProperty(dataType = "string",value = "Numero de identificacion del afiliado", required = true)
	@Pattern(message = "Los valores deben ser numeros enteros con longitud entre 1 y 20", regexp = "^(\\d{1,20})$")
	@NotNull
	private String numIdentificacion;

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumIdentificacion() {
		return numIdentificacion;
	}

	public void setNumIdentificacion(String numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}

}
