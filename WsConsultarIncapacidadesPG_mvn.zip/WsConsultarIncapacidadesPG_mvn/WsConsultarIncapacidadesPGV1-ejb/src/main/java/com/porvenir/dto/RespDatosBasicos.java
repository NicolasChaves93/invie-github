package com.porvenir.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class RespDatosBasicos 
{
	@JsonProperty("solicitudId")
	@ApiModelProperty(dataType = "integer",value = "Código identificador de solicitud", required = true)
	private int solicitudId;
	
	@JsonProperty("cuentaId")
	@ApiModelProperty(dataType = "integer",value = "Código identificador de la cuenta del afiliado", required = true)
	private int cuentaId;
	
	@JsonProperty("tipoSolicitud")
	@ApiModelProperty(dataType = "string",value = "Tipo de solicitud", required = true)
	private String tipoSolicitud;
	
	@JsonProperty("nombreReclamacion")
	@ApiModelProperty(dataType = "string",value = "Nombre del tipo de reclamacion", required = true)
	private String nombreReclamacion;
	
	@JsonProperty("tutela")
	@ApiModelProperty(dataType = "string",value = "Identifica si la solicitud es radicada como una tutela", required = true)
	private String tutela;
	
	@JsonProperty("fechaTutela")
	@ApiModelProperty(dataType = "string",value = "Fecha de la tutela", required = true)
	private String fechaTutela;
	
	@JsonProperty("fechaRadicacion")
	@ApiModelProperty(dataType = "string",value = "Fecha en que se radicó la solicitud", required = true)
	private String fechaRadicacion;
	
	@JsonProperty("tipoIdentificacion")
	@ApiModelProperty(dataType = "string",value = "Tipo de identificacion del afiliado", required = true)
	private String tipoIdentificacion;

	@JsonProperty("numIdentificacion")
	@ApiModelProperty(dataType = "string",value = "Numero de identificacion del afiliado", required = true)
	private String numIdentificacion;
	
	@JsonProperty("nombreAfiliado")
	@ApiModelProperty(dataType = "string",value = "Nombre del afiliado", required = true)
	private String nombreAfiliado;
	
	@JsonProperty("dia")
	@ApiModelProperty(dataType = "integer",value = "Día actual", required = true)
	private int dia;
	
	@JsonProperty("mes")
	@ApiModelProperty(dataType = "string",value = "Mes actual", required = true)
	private String mes;
	
	@JsonProperty("año")
	@ApiModelProperty(dataType = "integer",value = "Año actual", required = true)
	private int anio;

	public int getSolicitudId() {
		return solicitudId;
	}

	public void setSolicitudId(int solicitudId) {
		this.solicitudId = solicitudId;
	}

	public int getCuentaId() {
		return cuentaId;
	}

	public void setCuentaId(int cuentaId) {
		this.cuentaId = cuentaId;
	}

	public String getTipoSolicitud() {
		return tipoSolicitud;
	}

	public void setTipoSolicitud(String tipoSolicitud) {
		this.tipoSolicitud = tipoSolicitud;
	}

	public String getNombreReclamacion() {
		return nombreReclamacion;
	}

	public void setNombreReclamacion(String nombreReclamacion) {
		this.nombreReclamacion = nombreReclamacion;
	}

	public String getTutela() {
		return tutela;
	}

	public void setTutela(String tutela) {
		this.tutela = tutela;
	}
	
	public String getFechaTutela() {
		return fechaTutela;
	}

	public void setFechaTutela(String fechaTutela) {
		this.fechaTutela = fechaTutela;
	}

	public String getFechaRadicacion() {
		return fechaRadicacion;
	}

	public void setFechaRadicacion(String fechaRadicacion) {
		this.fechaRadicacion = fechaRadicacion;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumIdentificacion() {
		return numIdentificacion;
	}

	public void setNumIdentificacion(String numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}

	public String getNombreAfiliado() {
		return nombreAfiliado;
	}

	public void setNombreAfiliado(String nombreAfiliado) {
		this.nombreAfiliado = nombreAfiliado;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public String getMes() {
		return mes;
	}

	public void setMes(String mes) {
		this.mes = mes;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}
	
}
