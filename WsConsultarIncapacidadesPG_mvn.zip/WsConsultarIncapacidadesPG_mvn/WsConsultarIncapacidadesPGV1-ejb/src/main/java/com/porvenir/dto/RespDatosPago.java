package com.porvenir.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class RespDatosPago 
{
	@JsonProperty("fechaInicio")
	@ApiModelProperty(dataType = "string",value = "Fecha de inicio de la prórroga de la incapacidad", required = true)
	private String fechaInicio;
	
	@JsonProperty("fechaFin")
	@ApiModelProperty(dataType = "string",value = "Fecha de fin de la prórroga de la incapacidad", required = true)
	private String fechaFin;
	
	@JsonProperty("diasIncapacidad")
	@ApiModelProperty(dataType = "integer",value = "Cantidad de días de incapacidad", required = true)
	private Integer diasIncapacidad;
	
	@JsonProperty("valor")
	@ApiModelProperty(dataType = "double", value = "Valor pagado por la aseguradora", required = true)
	private double valor;
	
	@JsonProperty("conceptoPago")
	@ApiModelProperty(dataType = "string",value = "Concepto del pago", required = true)
	private String conceptoPago;
	
	@JsonProperty("estadoPagoSP")
	@ApiModelProperty(dataType = "string",value = "Estado del pago", required = true)
	private String estadoPagoSP;
	
	@JsonProperty("nombreBeneficiario")
	@ApiModelProperty(dataType = "string",value = "Nombre del beneficiario", required = true)
	private String nombreBeneficiario;

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Integer getDiasIncapacidad() {
		return diasIncapacidad;
	}

	public void setDiasIncapacidad(Integer diasIncapacidad) {
		this.diasIncapacidad = diasIncapacidad;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getConceptoPago() {
		return conceptoPago;
	}

	public void setConceptoPago(String conceptoPago) {
		this.conceptoPago = conceptoPago;
	}

	public String getEstadoPagoSP() {
		return estadoPagoSP;
	}

	public void setEstadoPagoSP(String estadoPagoSP) {
		this.estadoPagoSP = estadoPagoSP;
	}

	public String getNombreBeneficiario() {
		return nombreBeneficiario;
	}

	public void setNombreBeneficiario(String nombreBeneficiario) {
		this.nombreBeneficiario = nombreBeneficiario;
	}
	
}
