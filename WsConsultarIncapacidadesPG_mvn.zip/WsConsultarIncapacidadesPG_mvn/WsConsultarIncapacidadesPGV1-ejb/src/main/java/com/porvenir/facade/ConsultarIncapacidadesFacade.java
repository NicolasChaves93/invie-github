package com.porvenir.facade;

import java.util.ArrayList;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dao.ConsultarIncapacidadesDAO;
import com.porvenir.dto.ReqConsultarIncapacidadesPG;
import com.porvenir.dto.RespConsultarIncapacidadesPG;
import com.porvenir.dto.RespDatosBasicos;
import com.porvenir.dto.RespDatosPago;
import com.porvenir.dto.RespStatus;
import com.porvenir.exception.BusinessException;
import com.porvenir.validate.EnumTipoDocumento;

/**
 * Session Bean implementation class ConsultarIncapacidadesFacade
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@Stateless(name = "ConsultarIncapacidadesFacade", mappedName = "ejb/ConsultarIncapacidadesFacade")
public class ConsultarIncapacidadesFacade implements ConsultarIncapacidadesFacadeLocal 
{

	@EJB
	private ConsultarIncapacidadesDAO consultarIncapacidadesDAO;

	@Override
	public RespConsultarIncapacidadesPG consultarIncapacidades(ReqConsultarIncapacidadesPG reqConsultarIncapacidadesPG, Map<String, String> headerRequest) throws Exception, BusinessException
	{
		LogsController logger;
		logger = LogsController.getLogs();
		SearchProperties search = SearchProperties.getInstance();
		RespConsultarIncapacidadesPG respConsultarIncapacidadesPG = new RespConsultarIncapacidadesPG();
		RespDatosBasicos respDatosBasicos = new RespDatosBasicos();
		ArrayList<RespDatosPago> listRespDatosPagos = new ArrayList<RespDatosPago>();
		RespStatus status = new RespStatus();
		
		if(!validarDocumento(reqConsultarIncapacidadesPG.getTipoIdentificacion()))
		{
			logger.logWarning(ConstantesService.COD_ERROR_103_MESSAGE, headerRequest, ConsultarIncapacidadesFacade.class);
			throw new BusinessException(ConstantesService.COD_ERROR_103,
					search.searchParam(ConstantesService.COD_ERROR_103_MESSAGE));
		}
		
		try 
		{
			logger.logInfo("3", "Enviando datos", headerRequest, ConsultarIncapacidadesFacade.class);
			
			logger.logInfo("X", "Se entra a realizar el primer insert", headerRequest, ConsultarIncapacidadesFacade.class);			
			respDatosBasicos = consultarIncapacidadesDAO.datosBasicosIncapacidades
					(reqConsultarIncapacidadesPG.getTipoIdentificacion(), reqConsultarIncapacidadesPG.getNumIdentificacion());
			
			if(respDatosBasicos == null)
			{
				return null;
			}
			else
			{
				logger.logInfo("X", "Se entra a realizar el segundo insert", headerRequest, ConsultarIncapacidadesFacade.class);
				listRespDatosPagos = consultarIncapacidadesDAO.listaPagosIncapacidades(respDatosBasicos.getSolicitudId());
				if(listRespDatosPagos == null)
				{
					logger.logWarning(ConstantesService.COD_ERROR_105_MESSAGE, headerRequest, ConsultarIncapacidadesFacade.class);
					throw new BusinessException(ConstantesService.COD_ERROR_105,
							search.searchParam(ConstantesService.COD_ERROR_105_MESSAGE));
				}
			}
			respConsultarIncapacidadesPG.setDatosBasicos(respDatosBasicos);
			if(listRespDatosPagos.isEmpty())
			{
				respConsultarIncapacidadesPG.setContienePagos("N");
			}
			else
			{
				respConsultarIncapacidadesPG.setContienePagos("S");
			}
			respConsultarIncapacidadesPG.setListaPagos(listRespDatosPagos);
			
			logger.logInfo("X", "Se setea el status exitoso", headerRequest, ConsultarIncapacidadesFacade.class);
			status.setStatusCode(ConstantesService.COD_RESPUESTA_200);
			status.setStatusDesc(search.searchParam(ConstantesService.COD_RESPUESTA_200_MESSAGE));
			respConsultarIncapacidadesPG.setStatus(status);
			
			headerRequest = null;
			LogsController.destroyLog();
			logger = null;
			reqConsultarIncapacidadesPG = null;
			status = null;
			
			return respConsultarIncapacidadesPG;
		}
		catch (BusinessException e) 
		{
			logger.logWarning("Error en las consultas a la base de datos: " + e.toString(), headerRequest, ConsultarIncapacidadesFacade.class, e);
			throw e;
		}
		catch (Exception e) 
		{
			logger.logWarning("Error en las consultas a la base de datos: " + e.toString(), headerRequest, ConsultarIncapacidadesFacade.class, e);
			throw new Exception();
		}
	}
	
	private boolean validarDocumento(String valorAValidar)
	{
		for(EnumTipoDocumento a : EnumTipoDocumento.values())
		{
			if(valorAValidar.equals(a.toString()))
			{
				return true;
			}
		}
		return false;
	}
	
}
