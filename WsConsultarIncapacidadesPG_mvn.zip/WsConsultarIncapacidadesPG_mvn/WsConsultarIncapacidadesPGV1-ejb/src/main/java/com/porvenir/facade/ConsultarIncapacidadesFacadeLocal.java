package com.porvenir.facade;

import java.util.Map;

import javax.ejb.Local;

import com.porvenir.dto.ReqConsultarIncapacidadesPG;
import com.porvenir.dto.RespConsultarIncapacidadesPG;
import com.porvenir.exception.BusinessException;

/**
 * Interfaz EJB para el servicio de envio de SMS
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@Local
public interface ConsultarIncapacidadesFacadeLocal 
{
	public RespConsultarIncapacidadesPG consultarIncapacidades(ReqConsultarIncapacidadesPG reqConsultarIncapacidadesPG,Map<String, String> headerRequest) throws Exception, BusinessException;

}
