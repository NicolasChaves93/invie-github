package com.porvenir.conf;


import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;

import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.models.ExternalDocs;

/**
 * Clase con la información y configuración para la firma Swagger
 * @authoJorge Andres Amazo Contrerasce (POR08323)
 * @version 1.0
 * @since 31/01/2020
 */
public class Bootstrap extends HttpServlet {
	/**
	 * Parametro Serializable
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void init(ServletConfig config) throws ServletException { 
		super.init(config);
		SearchProperties.destroyInstance();
		SearchProperties searchProperties = SearchProperties.getInstance();

		BeanConfig beanConfig = new BeanConfig();
		beanConfig.setVersion(searchProperties.searchParam(ConstantesService.VERSION_SWAGGER_AAF11S02V01));
		beanConfig.setSchemes(new String[] { searchProperties.searchParam(ConstantesService.SCHEMES_SWAGGER_AAF11S02V01) });
		beanConfig.setHost(searchProperties.searchParam(ConstantesService.HOST_SWAGGER_AAF11S02V01));
		beanConfig.setBasePath(searchProperties.searchParam(ConstantesService.BASEPATH_SWAGGER_AAF11S02V01));
		beanConfig.setResourcePackage(searchProperties.searchParam(ConstantesService.PACKAGE_SWAGGER_AAF11S02V01));		
		beanConfig.setTitle(searchProperties.searchParam(ConstantesService.TITLE_SWAGGER_AAF11S02V01));
		
		beanConfig.setContact(searchProperties.searchParam(ConstantesService.CONTACT_SWAGGER));
		beanConfig.setDescription(searchProperties.searchParam(ConstantesService.CONTACT_DESCRIP_SWAGGER));
		beanConfig.setTermsOfServiceUrl(searchProperties.searchParam(ConstantesService.TERMS_SWAGGER));
		beanConfig.setLicense(searchProperties.searchParam(ConstantesService.LIC_SWAGGER));
		beanConfig.setLicenseUrl(searchProperties.searchParam(ConstantesService.LIC_URL_SWAGGER));
		
		beanConfig.setScan(true);
		beanConfig.getSwagger().externalDocs(new ExternalDocs(searchProperties.searchParam(ConstantesService.EXTERNAL_URL_DESC_SWAGGER),
				searchProperties.searchParam(ConstantesService.EXTERNAL_URL_SWAGGER)));
				
				ServletContext context = config.getServletContext();
				context.setAttribute("swagger", beanConfig.getSwagger());
		
	}
	
	@Override
	public void destroy() {
		SearchProperties.destroyInstance();
		LogsController.destroyLog();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		LogsController.getLogs().reloadConfigure();
		SearchProperties.getInstance();
	}
}
