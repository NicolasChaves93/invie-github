package com.porvenir.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dto.ReqConsultarIncapacidadesPG;
import com.porvenir.dto.RespConsultarIncapacidadesPG;
import com.porvenir.dto.RespStatus;
import com.porvenir.exception.BusinessException;
import com.porvenir.exception.HeaderValidateService;
import com.porvenir.exception.RespException;
import com.porvenir.exception.RespStatusExcepcion;
import com.porvenir.facade.ConsultarIncapacidadesFacadeLocal;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ResponseHeader;

/**
 * Controlador del servicio ConsultarIncapacidadesPG
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 2.0
 * @since 31/01/2020
 */
@Api()
@Path("/v1")
public class WsConsultarIncapacidadesPGController 
{ 
	private ConsultarIncapacidadesFacadeLocal consultarIncapacidadesFacade;
	@Context
	private HttpServletRequest request;
	
	/**
	 * Constante con el valor JDNI del EJB
	 */
	public static String EJB_INITIAL = "java:comp/env/ejb/ConsultarIncapacidadesFacade";

	@ApiResponses(value = {
			@ApiResponse(code = ConstantesService.COD_RESPUESTA_200, message = "OK -> Respuesta Exitosa", response = RespConsultarIncapacidadesPG.class, responseHeaders = {
					@ResponseHeader(name = "rqUID", description = "Identificador unico del mensaje.") }),
			@ApiResponse(code = ConstantesService.COD_ERROR_406, message = "NOT ACCEPTABLE -> Errores de Negocio", response = RespException.class, responseHeaders = {
					@ResponseHeader(name = "rqUID", description = "Identificador unico del mensaje.", response = String.class) }),
			@ApiResponse(code = ConstantesService.COD_ERROR_500, message = "INTERNAL SERVER ERROR -> Errores Internos o no controlados", response = RespException.class, responseHeaders = {
					@ResponseHeader(name = "rqUID", description = "Identificador unico del mensaje.", response = String.class) }) })

	@ApiOperation(value = "Servicio REST para consultar las incapacidades de un afiliado con sus pagos.", response = RespConsultarIncapacidadesPG.class, tags = "Consultar Incapacidades")

	@POST
	@Path(value = "/Consultar")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response consultarIncapacidades(
			@ApiParam(value = "Identificador de la entidad que consume el servicio", required = true, defaultValue = "Long. Maxima: 15") @HeaderParam(value = "clientID") String clientID,
			@ApiParam(value = "Identificador unico del mensaje", required = true, defaultValue = "Long. Maxima: 36") @HeaderParam(value = "rqUID") String rqUID,
			@ApiParam(value = "Identificador del servicio y operacion", required = true, defaultValue = "Long. 11") @HeaderParam(value = "serviceID") String serviceID,
			@ApiParam(value = "Corresponde al nombre de usuario que hizo el Login en la App", required = true, defaultValue = "Long. Maxima:30") @HeaderParam(value = "userTransaction") String userTransaction,
			@Valid @ApiParam(value = "") ReqConsultarIncapacidadesPG reqConsultarIncapacidadesPG) throws Exception 
	{
		Response response = null;
		RespConsultarIncapacidadesPG respConsultarIncapacidadesPG = new RespConsultarIncapacidadesPG();
		Map<String, String> headerRequest = new HashMap<String, String>();
		SearchProperties.destroyInstance();
		SearchProperties searchProperties = SearchProperties.getInstance();
		LogsController logger;
		logger = LogsController.getLogs();
		final String uuid = UUID.randomUUID().toString();
		
		request.getSession().setAttribute("transactionId", uuid);
		headerRequest.put("transactionId", uuid);

		if (clientID != null) {
			headerRequest.put("clientID", clientID);
		}
		if (rqUID != null) {
			headerRequest.put("rqUID", rqUID);
		}
		if (serviceID != null) {
			headerRequest.put("serviceID", serviceID);
		}
		if (userTransaction != null) {
			headerRequest.put("userTransaction", userTransaction);
		}
		logger.logInfo("1", "Validacion headers del request", headerRequest, WsConsultarIncapacidadesPGController.class);
		HeaderValidateService.validateRequiredHeader(
				searchProperties.searchParam(ConstantesService.HEADERS_REQUEST_REQUIRED), headerRequest);

		logger.logInfo("2", "Inicializacion del EJB", headerRequest, WsConsultarIncapacidadesPGController.class);
		consultarIncapacidadesFacade = (ConsultarIncapacidadesFacadeLocal) Comunes.getEJB(EJB_INITIAL);
		respConsultarIncapacidadesPG = consultarIncapacidadesFacade.consultarIncapacidades(reqConsultarIncapacidadesPG, headerRequest);
		
		if(respConsultarIncapacidadesPG == null)
		{
			logger.logInfo("4", "Respuesta exitosa sin datos", headerRequest, WsConsultarIncapacidadesPGController.class);
			RespException respException = new RespException(); 
			RespStatusExcepcion status = new RespStatusExcepcion();
			status.setStatusCode(ConstantesService.COD_ERROR_204);
			status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_204_MESSAGE));
			respException.setStatus(status);
			response = Comunes.headerResponse(rqUID, Status.OK, respException);
		}
		else
		{
			logger.logInfo("4", "Respuesta exitosa", headerRequest, WsConsultarIncapacidadesPGController.class);
			response = Comunes.headerResponse(rqUID, Status.OK, respConsultarIncapacidadesPG);
		}
		return response;
	}

}