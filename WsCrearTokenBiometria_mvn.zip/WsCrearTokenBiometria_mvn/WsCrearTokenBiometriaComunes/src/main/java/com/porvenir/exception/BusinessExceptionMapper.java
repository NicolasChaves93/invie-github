package com.porvenir.exception;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porvenir.comunes.Comunes;

/**
 * Clase donde se implementa el loger para mapear los errores de negocio
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 18/10/2019
 */
@Provider
public class BusinessExceptionMapper implements ExceptionMapper<BusinessException> { 
	@Context
	private HttpServletRequest request;

	@Override
	public Response toResponse(BusinessException exception) 
	{
		RespException resp = new RespException();
		RespStatusExcepcion status = new RespStatusExcepcion();
		Response response = null;
		Logger logger = null;
		String idTransaction = request.getSession().getAttribute("transactionId").toString();
		status.setStatusCode(exception.getCodigo());
		status.setStatusDesc(exception.getDescripcion());
		resp.setStatus(status);
		response = Comunes.headerResponse(request.getHeader("rqUID"), Status.NOT_ACCEPTABLE, resp);
		logger = LoggerFactory.getLogger(BusinessExceptionMapper.class);
		logger.error("[ ".concat(idTransaction).concat(" ] Error en las reglas de negocio"),exception);

		return response;
	}

}
