package com.porvenir.validate;

public enum EnumTipoDocumento 
{
	CC,TI,CE,NIT,REG,PAS;
}
