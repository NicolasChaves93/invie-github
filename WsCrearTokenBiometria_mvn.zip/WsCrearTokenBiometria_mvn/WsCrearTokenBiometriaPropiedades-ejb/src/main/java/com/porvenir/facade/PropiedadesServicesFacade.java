package com.porvenir.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.porvenir.comunes.PropiedadesServicesFacLocal;
import com.porvenir.dao.ParametrosGenericosDAO;
import com.porvenir.model.ParametrosGenericos;

/**
 * Servicio que realiza la consulta de las propiedades
 * @author Harry Hurtado Arango POR09786
 */
@Stateless(mappedName="ejb/PropiedadesServicesFacade")
public class PropiedadesServicesFacade implements PropiedadesServicesFacLocal 
{

	@EJB
	private ParametrosGenericosDAO propiedadesServiciosDAO;
    
    
    /**
     *  Busca todas las propiedades asociadas a un servicio
     * @param serviceId
     * @return
     * @throws Exception 
     */
    public  Map<String,String> findAllPropertiesByServicesId(String serviceId) throws Exception
    {
    	Map<String,String> mapValues=new HashMap<String, String>();
    	List<ParametrosGenericos> listaPropiedades;
		try {
			listaPropiedades = propiedadesServiciosDAO.getAllPropServiciosByServiceId(serviceId);
		} catch (Exception e) {
			throw new Exception();
		}
    	for(ParametrosGenericos propiedad:listaPropiedades)
    	{
    		mapValues.put((propiedad.getNombreParametro()), propiedad.getPropiedadValor());
    	}
    	serviceId = null;
    	listaPropiedades = null;
    	return mapValues;
    }

}
