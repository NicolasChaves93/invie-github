package com.porvenir.dao;


import javax.persistence.EntityManager;

/**
 * Modelo Abstracto que me define los metodos JPA para crear, buscar y eliminar
 * @author Harry Hurtado Arango(POR09786)
 * @version 1.0
 * @since 01/11/2019
 */
public abstract class AbstractDAO<E, PK> {
	
	private final  Class<E> entityClass;
	protected abstract EntityManager getEntityManager();

	/**
	 * Constructor de la clase AbstractDAO
	 * @param entityClass
	 */
	protected AbstractDAO(final Class<E> entityClass) {
		this.entityClass = entityClass;
	}

	/**
	 * Metodo para insertar datos en la BD
	 * @param entity Es la que contiene los valores para insertar en la BD
	 */
	public void create(final E entity) { 
		final EntityManager entityManager = getEntityManager();
		entityManager.persist(entity);
	}

	/**
	 * Metodo para para buscar en la BD
	 * @param id es la llave primaria para buscar en la BD
	 * @return
	 */
	public final E find(final PK id) {
		return getEntityManager().find(entityClass, id);
	}

	/**
	 * Metodo para para borrar los datos en la BD
	 * @param entity Es la que contiene los valores para eliminar
	 */
	public void remove(E entity) {
		getEntityManager().remove(entity);
	}

}