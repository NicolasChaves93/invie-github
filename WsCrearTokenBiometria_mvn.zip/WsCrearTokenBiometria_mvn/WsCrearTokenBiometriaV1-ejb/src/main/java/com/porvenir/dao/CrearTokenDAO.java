package com.porvenir.dao;

import javax.ejb.Local;

import com.porvenir.dto.RespCrearTokenBiometria;
import com.porvenir.exception.BusinessException;

/**
 * Interfaz que me representa la insercion de datos
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 30/10/2019
 */
@Local
public interface CrearTokenDAO 
{ 
	public int insertarBioProtoToken(String tipoIdentificacion, String numIdentificacion, String usuarioTotem, String hashToken);
	
	public int insertarBioValidacionRegistro(String tipoIdentificacion, String numIdentificacion, String usuarioTotem, String hashToken, int tipoToken, String ipTotem);
}
