package com.porvenir.dao;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dto.RespCrearTokenBiometria;

/**
 * Implementacion de la interfaz SMS
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 30/10/2019
 */
@Stateless
public class CrearTokenDAOImpl implements CrearTokenDAO{ 
	
	@PersistenceContext(unitName= "DbporveToken-PU")
	EntityManager em;

	@Override
	public int insertarBioProtoToken(String tipoIdentificacion, String numIdentificacion,
			String usuarioTotem, String hashToken) 
	{
		SearchProperties search = SearchProperties.getInstance();
		try
		{
			Date fechaHoy = new Date(Calendar.getInstance().getTimeInMillis());
			BigDecimal numId = new BigDecimal(numIdentificacion);
			
			Query q1 = em.createNativeQuery("insert into BIO_PROTO_TOKENS "
					+ "(USUARIO_ID, IDENTIFICACION, TIPO_ID, TOKEN, VALIDADO, USUARIO_CREACION, USUARIO_ULTIMA_MODIFICACION, FECHA_CREACION, FECHA_ULTIMA_MODIFICACION, MFONDOS_SCN)\n" +
					"values (?usuarioTotem, ?numId, ?tipoId, ?hashToken, ?validado, ?usuarioCreacion, null, ?fechaHoy, null, 0)");
			q1.setParameter("usuarioTotem", usuarioTotem);
			q1.setParameter("numId", numId);
			q1.setParameter("tipoId", tipoIdentificacion);
			q1.setParameter("hashToken", hashToken);
			q1.setParameter("usuarioCreacion", usuarioTotem);
			q1.setParameter("fechaHoy", fechaHoy);
			//Constantes de base de datos
			q1.setParameter("validado", search.searchParam(ConstantesService.BIO_PROTO_TOKEN_VALIDADO));
			int result = q1.executeUpdate();
			return result;
		}
		catch(Exception e)
		{
			return 0;
		}
	}
	
	@Override
	public int insertarBioValidacionRegistro(String tipoIdentificacion, String numIdentificacion, String usuarioTotem,
			String hashToken, int tipoToken, String ipTotem) 
	{
		SearchProperties search = SearchProperties.getInstance();
		try
		{
			BigDecimal idAutorizacion = null;
			BigDecimal tipoTokenBigDec = null;
			
			Query q1 = em.createNativeQuery("SELECT BIO_VALIDACION_REGISTRO_SEQ.nextval FROM dual");
			idAutorizacion = (BigDecimal) q1.getSingleResult();
			
			Date fechaHoy = new Date(Calendar.getInstance().getTimeInMillis());
			BigDecimal numId = new BigDecimal(numIdentificacion);
			
			Query q2 = em.createNativeQuery("insert into BIO_VALIDACION_REGISTRO (AUTORIZACION_ID, TIPO_ID, NUMERO_ID, ORIGEN, TIPO_OPERACION,"
					+ " LOG_BIOMETRIA, USUARIO_CREACION, FECHA_CREACION, AUTORIZACION_TERCERO, TIPO_EXCEPCION_ID, USUARIO_AUTORIZADOR, "
					+ "OBSERVACIONES_EXCEPCION, PRO_TOKEN_ID, ESTADO, FECHA_CONSUMO, CLIENTE_CONSUMO, USUARIO_CONSUMO, FECHA_ULTIMA_MODIFICACION,"
					+ " USUARIO_ULTIMA_MODIFICACION, MFONDOS_SCN, DEPID_CONSUMO) " + 
					"values (?idAutorizacion, ?tipoId, ?numId, ?origen, ?tipoToken, ?ipTotem, ?usuarioTotem, ?fechaHoy,"
					+ " ?autTercero, null, null, null, ?hashToken, ?estado, null, null, null, null, null, 0, null)");
			
			tipoTokenBigDec = new BigDecimal(tipoToken);
			q2.setParameter("idAutorizacion", idAutorizacion);
			q2.setParameter("tipoId", tipoIdentificacion);
			q2.setParameter("numId", numId);
			q2.setParameter("tipoToken", tipoTokenBigDec );
			q2.setParameter("ipTotem", ipTotem);
			q2.setParameter("usuarioTotem", usuarioTotem);
			q2.setParameter("fechaHoy", fechaHoy);
			q2.setParameter("hashToken", hashToken);
			//Constantes de base de datos
			q2.setParameter("origen", search.searchParam(ConstantesService.BIO_VALIDACION_REGISTRO_ORIGEN));
			q2.setParameter("autTercero", search.searchParam(ConstantesService.BIO_VALIDACION_REGISTRO_AUT_TERCERO));
			q2.setParameter("estado", search.searchParam(ConstantesService.BIO_VALIDACION_REGISTRO_ESTADO_VAL));
			int result = q2.executeUpdate();
			return result;
		}
		catch(Exception e)
		{
			return 0;
		}
	}
}
