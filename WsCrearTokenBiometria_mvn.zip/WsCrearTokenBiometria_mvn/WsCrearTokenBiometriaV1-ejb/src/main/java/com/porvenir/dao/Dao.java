package com.porvenir.dao;

/**
 * Interfaz DAO
 * 
 * @author POR08323
 *
 * @param <K>
 *            Tipo de la llave primaria
 * @param <E>
 *            Entidad
 */
public interface Dao<K, E> {
	/**
	 * permite realizar el persis de la data
	 * @param entity
	 */
	void persist(E entity);

	/**
	 * Permite eliminar las entidades de 
	 * @param entity
	 */
	void remove(E entity);

	/**
	 * Busqueda por Id
	 * @param id
	 * @return
	 */
	E findById(K id);

}