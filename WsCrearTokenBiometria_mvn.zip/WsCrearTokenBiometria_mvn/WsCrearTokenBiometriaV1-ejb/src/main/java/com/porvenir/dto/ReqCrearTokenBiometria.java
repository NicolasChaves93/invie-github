package com.porvenir.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto entrada del servicio SMS
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@ApiModel
public class ReqCrearTokenBiometria {

	@Valid
	@JsonProperty("tipoIdentificacion")
	@Size(min = 2, max = 5, message="Tamaño del texto invalido")
	@ApiModelProperty(value = "Tipo de identificacion del afiliado", required = true)
	@Pattern(regexp="[A-Za-z]*", message="Caracteres Invalidos")
	@NotNull
	private String tipoIdentificacion;

	@Valid
	@JsonProperty("numIdentificacion")
	@ApiModelProperty(dataType = "string",value = "Numero de identificacion del afiliado", required = true)
	@Pattern(message = "Los valores deben ser numeros enteros con longitud entre 1 y 20", regexp = "^(\\d{1,20})$")
	@NotNull
	private String numIdentificacion;
	
	@Valid
	@JsonProperty("tipoToken")
	@ApiModelProperty(dataType = "int",value = "Tipo del token a crear", required = true)
	@NotNull
	private Integer tipoToken;
	
	@Valid
	@JsonProperty("usuarioTotem")
	@Size(min = 1, message="Tamaño del texto invalido")
	@ApiModelProperty(dataType = "string",value = "Nombre del usuario del totem", required = true)
	@NotNull
	private String usuarioTotem;
	
	@Valid
	@JsonProperty("ipTotem")
	@Size(min = 1, message="Tamaño del texto invalido")
	@ApiModelProperty(dataType = "string",value = "Ip del totem", required = true)
	@NotNull
	private String ipTotem;

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumIdentificacion() {
		return numIdentificacion;
	}

	public void setNumIdentificacion(String numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}

	public int getTipoToken() {
		return tipoToken;
	}

	public void setTipoToken(int tipoToken) {
		this.tipoToken = tipoToken;
	}

	public String getUsuarioTotem() {
		return usuarioTotem;
	}

	public void setUsuarioTotem(String usuarioTotem) {
		this.usuarioTotem = usuarioTotem;
	}

	public String getIpTotem() {
		return ipTotem;
	}

	public void setIpTotem(String ipTotem) {
		this.ipTotem = ipTotem;
	}
	
}
