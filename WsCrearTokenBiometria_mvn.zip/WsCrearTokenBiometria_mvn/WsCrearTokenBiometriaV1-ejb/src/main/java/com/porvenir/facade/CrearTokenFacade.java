package com.porvenir.facade;

import java.security.MessageDigest;
import java.util.Map;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dao.CrearTokenDAO;
import com.porvenir.dto.ReqCrearTokenBiometria;
import com.porvenir.dto.RespCrearTokenBiometria;
import com.porvenir.dto.RespStatus;
import com.porvenir.exception.BusinessException;
import com.porvenir.validate.EnumTipoDocumento;

/**
 * Session Bean implementation class SmsFacade
 * 
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@Stateless(name = "CrearTokenFacade", mappedName = "ejb/CrearTokenFacade")
public class CrearTokenFacade implements CrearTokenFacadeLocal 
{

	@EJB
	private CrearTokenDAO crearTokenDAO;

	@Override
	public RespCrearTokenBiometria crearToken(ReqCrearTokenBiometria reqCrearTokenBiometria, Map<String, String> headerRequest) throws Exception, BusinessException
	{
		LogsController logger;
		logger = LogsController.getLogs();
		SearchProperties search = SearchProperties.getInstance();
		RespCrearTokenBiometria respCrearTokenBiometria = new RespCrearTokenBiometria();
		RespStatus status = new RespStatus();
		
		if(!validarDocumento(reqCrearTokenBiometria.getTipoIdentificacion()))
		{
			logger.logWarning(ConstantesService.COD_ERROR_103_MESSAGE, headerRequest, CrearTokenFacade.class);
			throw new BusinessException(ConstantesService.COD_ERROR_103,
					search.searchParam(ConstantesService.COD_ERROR_103_MESSAGE));
		}		
		try 
		{
			logger.logInfo("3", "Enviando datos", headerRequest, CrearTokenFacade.class);
			
			int primerInsert = 0;
			int segundoInsert = 0;
			logger.logInfo("X", "Se procede a crear el HashToken", headerRequest, CrearTokenFacade.class);
			String hashToken = creaProtoToken(reqCrearTokenBiometria.getUsuarioTotem(), 
					reqCrearTokenBiometria.getTipoIdentificacion(), reqCrearTokenBiometria.getNumIdentificacion());
			
			logger.logInfo("X", "Se entra a realizar el primer insert", headerRequest, CrearTokenFacade.class);			
			primerInsert = crearTokenDAO.insertarBioProtoToken(reqCrearTokenBiometria.getTipoIdentificacion(), 
					reqCrearTokenBiometria.getNumIdentificacion(), reqCrearTokenBiometria.getUsuarioTotem(), hashToken);
			
			if(primerInsert == 0)
			{
				logger.logWarning(ConstantesService.COD_ERROR_104_MESSAGE, headerRequest, CrearTokenFacade.class);
				throw new BusinessException(ConstantesService.COD_ERROR_104,
						search.searchParam(ConstantesService.COD_ERROR_104_MESSAGE));
			}
			else
			{
				logger.logInfo("X", "Se entra a realizar el segundo insert", headerRequest, CrearTokenFacade.class);
				segundoInsert = crearTokenDAO.insertarBioValidacionRegistro(reqCrearTokenBiometria.getTipoIdentificacion(), reqCrearTokenBiometria.getNumIdentificacion(), reqCrearTokenBiometria.getUsuarioTotem(), hashToken, reqCrearTokenBiometria.getTipoToken(), reqCrearTokenBiometria.getIpTotem());
				if(segundoInsert == 0)
				{
					logger.logWarning(ConstantesService.COD_ERROR_105_MESSAGE, headerRequest, CrearTokenFacade.class);
					throw new BusinessException(ConstantesService.COD_ERROR_105,
							search.searchParam(ConstantesService.COD_ERROR_105_MESSAGE));
				}
			}
			
			logger.logInfo("X", "Se setea el status exitoso", headerRequest, CrearTokenFacade.class);
			status.setStatusCode(ConstantesService.COD_RESPUESTA_200);
			status.setStatusDesc(search.searchParam(ConstantesService.COD_RESPUESTA_200_MESSAGE));
			respCrearTokenBiometria.setStatus(status);
			
			headerRequest = null;
			LogsController.destroyLog();
			logger = null;
			reqCrearTokenBiometria = null;
			status = null;
			
			return respCrearTokenBiometria;
		}
		catch (BusinessException e) 
		{
			logger.logWarning("Error en el facade: " + e.toString(), headerRequest, CrearTokenFacade.class, e);
			throw e;
		}
		catch (Exception e) 
		{
			logger.logWarning("Error no controlado en el facade: " + e.toString(), headerRequest, CrearTokenFacade.class, e);
			throw new Exception();
		}
	}
	
	private boolean validarDocumento(String valorAValidar)
	{
		for(EnumTipoDocumento a : EnumTipoDocumento.values())
		{
			if(valorAValidar.equals(a.toString()))
			{
				return true;
			}
		}
		return false;
	}
	
	public String creaProtoToken(String usuarioTotem, String tipoId, String numId)
	{
		MessageDigest md = null;
		String ret;
		String pHashResult = "";
		long stime = 0;

		try 
		{
			stime = System.currentTimeMillis();
			ret = usuarioTotem + tipoId + numId + stime;

			md = MessageDigest.getInstance("MD5");
			md.update(ret.getBytes());

			byte[] digest = md.digest();
			StringBuffer buffer = new StringBuffer();

			for (int j = 0; j < digest.length; j++) {
				buffer.append((int) digest[j]);
			}
			pHashResult = buffer.toString().replaceAll("-", "");

			return pHashResult;
		}
		catch (Exception ex) 
		{
			return null;
		}
	}


}
