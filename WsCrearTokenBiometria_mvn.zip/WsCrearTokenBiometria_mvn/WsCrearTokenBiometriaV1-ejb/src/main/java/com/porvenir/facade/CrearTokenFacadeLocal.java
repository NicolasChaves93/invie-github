package com.porvenir.facade;

import java.util.Map;

import javax.ejb.Local;

import com.porvenir.dto.ReqCrearTokenBiometria;
import com.porvenir.dto.RespCrearTokenBiometria;
import com.porvenir.exception.BusinessException;

/**
 * Interfaz EJB para el servicio de envio de SMS
 * @author Jorge Andres Amazo Contreras (POR08323)
 * @version 1.0
 * @since 29/10/2019
 */
@Local
public interface CrearTokenFacadeLocal {
	public RespCrearTokenBiometria crearToken(ReqCrearTokenBiometria reqConsultaPagoPensional,Map<String, String> headerRequest) throws Exception, BusinessException;

}
