package com.porvenir.dao;

import java.util.List;

import javax.ejb.Local;

import com.porvenir.model.ParametrosGenericos;


/**
 * Interfaz DAO para las propiedades de los servicios 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 13/11/2019
 */
@Local
public interface ParametrosGenericosDAO {
	/**
	 * operacion dao encargado de buscar las propiedades por servicio
	 * @param serviceId
	 * @return
	 */
	public List<ParametrosGenericos> getAllPropServiciosByServiceId(String serviceId);

}
