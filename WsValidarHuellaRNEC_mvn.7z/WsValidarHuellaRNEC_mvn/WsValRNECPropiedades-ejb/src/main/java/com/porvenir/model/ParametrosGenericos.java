package com.porvenir.model;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * 
 * @author Harry Hurtado Arango POR09786
 *
 */
@Entity
@Table(name = "GEN_PARAMETRO", schema = "MGENERAL")
@NamedQueries({
	@NamedQuery(name="PropiedadesServicios.findAllByServiceId",query="SELECT b FROM ParametrosGenericos b WHERE b.idModulo=:idModulo AND b.nombreParametro LIKE :idServicio")
})
public class ParametrosGenericos { 

	
	@Id
	@Column(name = "PARAMETRO_ID")
	private BigInteger paramId;
	
	@Column(name = "MODULO_ID")
	private Integer idModulo;
	
	@Column(name = "ABREVIATURA")
	private String nombreParametro;
	
	@Column(name = "VALOR")
	private String propiedadValor;
	
	@Column(name = "USUARIO_CREACION")
	private String usuarioCreacion;
	@Column(name = "FECHA_CREACION")
	private Date fechaCreacion;
	@Column(name = "USUARIO_ULTIMA_MODIFICACION")
	private String usuarioModificacion;
	@Column(name = "FECHA_ULTIMA_MODIFICACION")
	private Date fechaModificacion;

	public String getPropiedadValor() {
		return propiedadValor;
	}

	public void setPropiedadValor(String propiedadValor) {
		this.propiedadValor = propiedadValor;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public BigInteger getParamId() {
		return paramId;
	}

	public void setParamId(BigInteger paramId) {
		this.paramId = paramId;
	}

	public Integer getIdModulo() {
		return idModulo;
	}

	public void setIdModulo(Integer idModulo) {
		this.idModulo = idModulo;
	}

	public String getNombreParametro() {
		return nombreParametro;
	}

	public void setNombreParametro(String nombreParametro) {
		this.nombreParametro = nombreParametro;
	}



}
