package com.porvenir.commons;

/**
 * ConstantesBiometrica.java Esta es la clase de constantes del servicio que
 * contienen la llave para buscar en el archivo properties
 * 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version: 1.0
 * @since: 08/10/2019
 */

public final class ConstantesRNEC { 
	private ConstantesRNEC() {
	}

	/**
	 * URL del servicio SOAP Porvenir
	 */
	public final static String URL_GGE05S03V01 = "GGE05S03V01.url";

	// Parametros para firma Swagger
	/**
	 * Informacion de contacto para la firma Swagger
	 */
	public final static String CONTACT_SWAGGER = "GGE05S03V01.swagger.contact";

	/**
	 * Descripcion de contacto para la firma Swagger
	 */
	public final static String CONTACT_DESCRIP_SWAGGER = "GGE05S03V01.swagger.contact.descrip";

	/**
	 * Informacion de los terminos y condiciones para la firma Swagger
	 */
	public final static String TERMS_SWAGGER = "GGE05S03V01.swagger.terminos";

	/**
	 * licencia para la firma Swagger
	 */
	public final static String LIC_SWAGGER = "GGE05S03V01.swagger.licencia";

	/**
	 * URL de la licencia Porvenir
	 */
	public final static String LIC_URL_SWAGGER = "GGE05S03V01.swagger.licencia.url";

	/**
	 * URL externa para mas informacion del proyecto Swagger
	 */
	public final static String EXTERNAL_URL_SWAGGER = "GGE05S03V01.swagger.external.url";

	/**
	 * Descripcion de la URL externa del proyecto Swagger
	 */
	public final static String EXTERNAL_URL_DESC_SWAGGER = "GGE05S03V01.swagger.external.descrip";

	/**
	 * Version actual de la firma Swagger
	 */
	public final static String VERSION_SWAGGER_GGE05S03V01 = "GGE05S03V01.swagger.version";

	/**
	 * informacion del Schema del servicio para Swagger
	 */
	public final static String SCHEMES_SWAGGER_GGE05S03V01 = "GGE05S03V01.swagger.schemes";

	/**
	 * informacion del Host para la firma Swagger
	 */
	public final static String HOST_SWAGGER_GGE05S03V01 = "GGE05S03V01.swagger.host";

	/**
	 * informacion del path para la firma Swagger
	 */
	public final static String BASEPATH_SWAGGER_GGE05S03V01 = "GGE05S03V01.swagger.path.base";

	/**
	 * informacion del paquete para la firma Swagger
	 */
	public final static String PACKAGE_SWAGGER_GGE05S03V01 = "GGE05S03V01.swagger.package";

	/**
	 * Titulo del servicio Swagger
	 */
	public final static String TITLE_SWAGGER_GGE05S03V01 = "GGE05S03V01.swagger.title";

	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String HEADERS_REQUEST_REQUIRED = "GGE05S03V01.headers.required";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String POLITICA = "GGE05S03V01.POLITICA";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String SUSCRIPCION = "GGE05S03V01.SUSCRIPCION";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String ID_CLIENTE = "GGE05S03V01.ID_CLIENTE";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String URL_CERT_CLIENT = "GGE05S03V01.URL_CERT_CLIENT";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String CERT_CLIENT_PASS = "GGE05S03V01.CERT_CLIENT_PASS";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String URL_CERT_SERVICE = "GGE05S03V01.URL_CERT_SERVICE";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String END_POINT = "GGE05S03V01.END_POINT";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String TIMER_SERVICE = "GGE05S03V01.TIMER_SERVICE";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String CODIGO_AUT = "GGE05S03V01.CODIGO_AUT";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String FORMATO_HUELLAS = "GGE05S03V01.FORMATO_HUELLAS";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String AUTORIZADO = "Autorizado";
	
	/**
	 * ValidityCode para validar en BD si esta o no autorizado
	 */
	public final static String VALIDITYCODE = "ValidityCode";
	
	/**
	 * Cabeceras obligatorias del servicio
	 */
	public final static String METADATA_REQUIRED = "metadata.required";
}
