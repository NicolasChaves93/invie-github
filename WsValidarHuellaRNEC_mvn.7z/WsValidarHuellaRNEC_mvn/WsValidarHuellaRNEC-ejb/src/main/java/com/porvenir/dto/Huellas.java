package com.porvenir.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto con la informacion de la huella
 * 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 24/10/2019
 */
@ApiModel
public class Huellas implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Valid
	@JsonProperty("id_huella")
	@ApiModelProperty(value = "Identifica el dedo al que pertenece la huella", example = "Pulgar derecho=1", required = true)
	@NotNull
	private String id_huella;

	@Valid
	@JsonProperty("datos")
	@ApiModelProperty(value = "Datos de la minucia en Base64", required = true)
	@NotNull
	private String datos;

	public String getId_huella() {
		return id_huella;
	}

	public void setId_huella(String id_huella) {
		this.id_huella = id_huella;
	}

	public String getDatos() {
		return datos;
	}

	public void setDatos(String datos) {
		this.datos = datos;
	}

}
