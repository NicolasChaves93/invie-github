package com.porvenir.dto;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto con la informacion de la Metadata
 * 
 * @author Willliam Castelblanco Galindo
 * @version 1.0
 * @since 04/02/2020
 */
@ApiModel
public class MetadataRest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Valid
	@JsonProperty("llave")
	@ApiModelProperty(value = "xxx", required = true)
	@NotNull
	private String llave;

	@Valid
	@JsonProperty("valor")
	@ApiModelProperty(value = "xxx", required = true)
	@NotNull
	private String valor;


	public String getLlave() {
		return llave;
	}

	public void setLlave(String llave) {
		this.llave = llave;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
	
}
