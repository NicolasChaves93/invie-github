package com.porvenir.dto;

import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto de entrada para el servicio RNEC
 * 
 * @author William Castelblanco Galindo (POR09785)
 * @version 1.0
 * @since 04/02/2020
 */
@ApiModel
public class ReqRNEC {

	@Valid
	@JsonProperty("nuip")
	@ApiModelProperty(value = "Numero unico de identidad personal", example = "0080800123", required = true)
	@NotNull
	private String nuip;

	@Valid
	@JsonProperty("huellas")
	@ApiModelProperty(value = "Arreglo con elementos de tipo Huella", required = true)
	@NotNull
	private List<Huellas> huellas;

	@Valid
	@JsonProperty("metadata")
	@ApiModelProperty(value = "Arreglo con elementos tipo metadata", required = true)
	@NotNull
	private List<MetadataRest> metadata;
	
	@Valid
	@JsonProperty("idtotem")
	@ApiModelProperty(value = "Identificador Totem", required = true)
	@NotNull
	private String idtotem;

	public String getNuip() {
		return nuip;
	}

	public void setNuip(String nuip) {
		this.nuip = nuip;
	}

	public List<Huellas> getHuellas() {
		return huellas;
	}

	public void setHuellas(List<Huellas> huellas) {
		this.huellas = huellas;
	}
	
	public List<MetadataRest> getMetadata() {
		return metadata;
	}

	public void setMetadata(List<MetadataRest> metadata) {
		this.metadata = metadata;
	}

	public String getIdtotem() {
		return idtotem;
	}

	public void setIdtotem(String idtotem) {
		this.idtotem = idtotem;
	}
}
