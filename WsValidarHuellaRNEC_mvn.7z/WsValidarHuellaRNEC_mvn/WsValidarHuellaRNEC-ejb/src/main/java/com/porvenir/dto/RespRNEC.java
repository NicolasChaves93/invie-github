package com.porvenir.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author William Castelblanco
 *
 */
@ApiModel
public class RespRNEC 
{
	@JsonProperty("status")
	@ApiModelProperty(value = "Objeto con el estado de la respuesta servicio")
	private RespStatus status;

	@JsonProperty("electronicData")
	@ApiModelProperty(value = "Objeto con el estado de la respuesta servicio")
	private String electronicData;
	
	public RespStatus getStatus() {
		return status;
	}

	public void setStatus(RespStatus status) {
		this.status = status;
	}

	public String getElectronicData() {
		return electronicData;
	}

	public void setElectronicData(String electronicData) {
		this.electronicData = electronicData;
	}
	
}
