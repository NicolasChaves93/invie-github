package com.porvenir.facade;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ws.rs.core.Response.Status;

import com.porvenir.commons.ConstantesRNEC;
import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.LogsController;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dto.Huellas;
import com.porvenir.dto.MetadataRest;
import com.porvenir.dto.ReqRNEC;
import com.porvenir.dto.RespRNEC;
import com.porvenir.dto.RespStatus;
import com.porvenir.exception.BusinessException;

import co.com.certicamara.util.Huella;
import co.com.certicamara.util.Metadata;
import co.com.certicamara.util.Verificacion;
import co.com.certicamara.util.VerificacionRequest;
import co.com.certicamara.util.VerificacionResponse;
import co.com.certicamara.util.Verificaciones;
import co.com.certicamara.util.VerificacionesClient;

/**
 * Metodo de la implementacion del EJB del servicio
 * 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 15/10/2019
 */
@Stateless(name = "ValidaHuellaRNECFacade", mappedName = "ejb/ValidaHuellaRNECFacade")
public class ValidaHuellaRNECFacade implements ValidaHuellaRNECFacadeLocal {

	@Override
	public RespRNEC validHuellaIdentity(ReqRNEC reqRNEC, Map<String, String> headerRequest) throws Exception 
	{
		RespRNEC respRNEC = null;
		RespStatus status = null;
		VerificacionRequest reqCertiHuellaSoap = null;
		Verificaciones cerRNEC = null;
		VerificacionResponse respuesta = null;
		LogsController logger = LogsController.getLogs();
		SearchProperties searchProperties = SearchProperties.getInstance();

		try
		{
			respRNEC = new RespRNEC();
			status = new RespStatus();
			reqCertiHuellaSoap = new VerificacionRequest();
			reqCertiHuellaSoap.setVerificacion(new Verificacion());
			reqCertiHuellaSoap.getVerificacion().setHuellas(new ArrayList<Huella>());
			reqCertiHuellaSoap.getVerificacion().setMetadata(new ArrayList<Metadata>());
		
			// Huellas
			if (reqRNEC.getHuellas() != null && !reqRNEC.getHuellas().isEmpty()) 
			{
				if(reqRNEC.getHuellas().size() < 2)
				{
					status.setStatusCode(ConstantesService.COD_ERROR_103);
					status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_103_MESSAGE));
					respRNEC.setStatus(status);
					return respRNEC;
				}
				copyObjectHuella(reqCertiHuellaSoap, reqRNEC.getHuellas(), searchProperties.searchParam(ConstantesRNEC.FORMATO_HUELLAS));
			}
			//Metadata
			if(!validacionMetadataRequerido(reqRNEC.getMetadata(), searchProperties))
			{
				status.setStatusCode(ConstantesService.COD_ERROR_104);
				status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_104_MESSAGE));
				respRNEC.setStatus(status);
				return respRNEC;
			}
			copyObjectMetadata(reqCertiHuellaSoap,reqRNEC.getMetadata());
			
			logger.logInfo("1", "Se llenan las clases de metadata y huellas", headerRequest, ValidaHuellaRNECFacade.class);
				
			reqCertiHuellaSoap.getVerificacion().setId_politica(searchProperties.searchParam(ConstantesRNEC.POLITICA));
			//reqCertiHuellaSoap.getVerificacion().setId_politica("Pol_Prod_Porvenir_Sup");
			reqCertiHuellaSoap.getVerificacion().setNuip(Comunes.rellenarNuip(reqRNEC.getNuip()));
			reqCertiHuellaSoap.getVerificacion().setSuscripcion(searchProperties.searchParam(ConstantesRNEC.SUSCRIPCION));
			//reqCertiHuellaSoap.getVerificacion().setSuscripcion("Usu_Pro_Porvenir_Suprema");
			reqCertiHuellaSoap.getVerificacion().setIdcliente(searchProperties.searchParam(ConstantesRNEC.ID_CLIENTE));
			//reqCertiHuellaSoap.getVerificacion().setIdcliente("2c6b953be8a9e130d172b606715d386edd9374712d9899d6f619c7e75a1fbe27");
			
		    cerRNEC = new VerificacionesClient();
		    logger.logInfo("2", "Se instancia la clase de Verificaciones", headerRequest, ValidaHuellaRNECFacade.class);
		    cerRNEC.setClientCertificate(searchProperties.searchParam(ConstantesRNEC.URL_CERT_CLIENT), searchProperties.searchParam(ConstantesRNEC.CERT_CLIENT_PASS));
		    //cerRNEC.setClientCertificate(searchProperties.searchParam(ConstantesRNEC.URL_CERT_CLIENT), "P0rvenir2019");
		    cerRNEC.setServiceCertificate(searchProperties.searchParam(ConstantesRNEC.URL_CERT_SERVICE));
		    cerRNEC.setIncludeTimeStamp(true);        
		    cerRNEC.setEndPoint(searchProperties.searchParam(ConstantesRNEC.END_POINT));
		    //cerRNEC.setEndPoint("https://www.certihuella.co/autenticacionTS");
		    
			logger.logInfo("3", "Se va a consumir el servicio de Certicamara", headerRequest, ValidaHuellaRNECFacade.class);
			try
			{
				respuesta = cerRNEC.verificacion(reqCertiHuellaSoap);
			}
			catch(Exception e)
			{
				logger.logInfo("x", "Error al consumir el servicio de certicamara: " + e.toString(), headerRequest, ValidaHuellaRNECFacade.class);
				status.setStatusCode(ConstantesService.COD_ERROR_105);
				status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_105_MESSAGE) + e.toString());
				respRNEC.setStatus(status);
				respRNEC.setElectronicData(null);
				return respRNEC;
			}
			logger.logInfo("4", "Se consumio correctamente", headerRequest, ValidaHuellaRNECFacade.class);
			
			status.setStatusCode(ConstantesService.COD_RESPUESTA_200);
			respRNEC.setElectronicData(getTokenTransaction(respuesta));
			logger.logInfo("5", "Se setea correctamente el token", headerRequest, ValidaHuellaRNECFacade.class);
			if(respuesta.getDecision().equals(ConstantesRNEC.AUTORIZADO))
			{
				status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_RESPUESTA_200_NO));
				String codigosAut = searchProperties.searchParam(ConstantesRNEC.CODIGO_AUT);
				String[] cods = codigosAut.split(",");
				for(Metadata met : respuesta.getInformacion_adicional())
				{
					if(met.getLlave().equals(ConstantesRNEC.VALIDITYCODE))
					{
						for(int  i = 0 ; i < cods.length ; i++)
						{
							if(cods[i].equals(met.getValor()))
							{
					        	status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_RESPUESTA_200_AUT));
					        	break;
							}
						}
						break;
					}
				}
			}
			else
			{
				status.setStatusCode(ConstantesService.COD_RESPUESTA_200);
		    	status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_RESPUESTA_200_NO));
			}
			respRNEC.setStatus(status);
		}
		catch(Exception e)
		{
			logger.logInfo("1", "Excepcion RNEC: " + e.toString(), headerRequest, ValidaHuellaRNECFacade.class);
			throw new Exception();
		}
		respuesta = null;
		cerRNEC = null;
		logger = null;
		headerRequest = null;
		reqRNEC = null;
		searchProperties = null;
		status = null;
		return respRNEC;
	}

/**
 * Método para adicionar el objeto de metadato al request del API
 * @param reqCertiHuellaSoap
 * @param metadataList
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 */
	private void copyObjectMetadata(VerificacionRequest reqCertiHuellaSoap, List<MetadataRest> metadataList) throws IllegalAccessException, InvocationTargetException 
	{
		List<Metadata> listMetadatas = new ArrayList<Metadata>();
		for(MetadataRest metadataRest : metadataList)
		{
			Metadata metadataSoap = new Metadata();
			if(metadataRest.getLlave() != null && !metadataRest.getLlave().isEmpty())
			{
				metadataSoap.setLlave(metadataRest.getLlave());
				metadataSoap.setValor(metadataRest.getValor());
				listMetadatas.add(metadataSoap);
			}
		}
		reqCertiHuellaSoap.getVerificacion().setMetadata(listMetadatas);
		listMetadatas = null;
	}
	
	/**
	 *Método para adicionar el objeto de huellas al request del API 
	 * @param reqCertiHuellaSoap
	 * @param huellasList
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	private void copyObjectHuella(VerificacionRequest reqCertiHuellaSoap, List<Huellas> huellasList, String formato) 
	{
		List<Huella> listHuellas = new ArrayList<Huella>();
		for (Huellas huellaRest : huellasList) 
		{
			Huella huellasSoap = new Huella();
			if (huellaRest.getId_huella() != null && !huellaRest.getId_huella().isEmpty()) 
			{
				huellasSoap.setId_huella(huellaRest.getId_huella());
				huellasSoap.setFormato(formato);
				huellasSoap.setDatos(huellaRest.getDatos());
				listHuellas.add(huellasSoap);
			}
		}
		reqCertiHuellaSoap.getVerificacion().setHuellas(listHuellas);
		listHuellas = null;
	}
	
	/**
	 * Metodo para realizar validación de metadata ontenida en el response
	 * @param metadataList
	 * @param search
	 * @return
	 */
	private boolean validacionMetadataRequerido(List<MetadataRest> metadataList, SearchProperties search)
	{
		String metadataProperties = search.searchParam(ConstantesRNEC.METADATA_REQUIRED);
		String[] llaves = metadataProperties.split(",");
		int cont = 0;
		if(metadataList.size() < llaves.length)
		{
			return false;
		}
		for(MetadataRest m : metadataList)
		{
			for(int i = 0 ; i < llaves.length ; i++)
			{
				if(llaves[i].equals(m.getLlave()))
				{
					cont++;
					break;
				}
			}
		}
		if(cont<llaves.length)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	private String getTokenTransaction(VerificacionResponse respuesta) 
	{
		String token = respuesta.getToken_transaccion();
		byte[] bites = token.getBytes(StandardCharsets.UTF_8);
		token = null;
		return bites.toString();
	}
}
