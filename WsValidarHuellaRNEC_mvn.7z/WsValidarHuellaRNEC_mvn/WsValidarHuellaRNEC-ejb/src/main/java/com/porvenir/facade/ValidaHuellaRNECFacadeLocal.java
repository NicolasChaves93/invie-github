package com.porvenir.facade;

import java.util.Map;

import javax.ejb.Local;

import com.porvenir.dto.ReqRNEC;
import com.porvenir.dto.RespRNEC;
import com.porvenir.exception.BusinessException;

/**
 * Interfaz del servicio validar Biometria
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 2.0
 * @since 24/10/2019
 */
@Local
public interface ValidaHuellaRNECFacadeLocal { 
	public RespRNEC validHuellaIdentity(ReqRNEC reqRNEC,Map<String, String> headerRequest) throws Exception;
}
