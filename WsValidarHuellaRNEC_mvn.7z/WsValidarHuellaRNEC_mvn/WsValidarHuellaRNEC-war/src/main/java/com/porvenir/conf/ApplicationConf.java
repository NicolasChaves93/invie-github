package com.porvenir.conf;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

//import org.glassfish.jersey.server.ServerProperties;

import com.porvenir.controller.WsValidacionRNECController;
import com.porvenir.exception.BusinessExceptionMapper;
import com.porvenir.exception.ConstraintExceptionMapper;
import com.porvenir.exception.InternalExcpetionMapper;

/**
 * ApplicationConf.java clase que contiene la configuracion del servicio
 * 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 09/10/2019
 */
@ApplicationPath("rest")
public class ApplicationConf extends Application {

	public Set<java.lang.Class<?>> getClasses() {
		Set<java.lang.Class<?>> resources = new HashSet<Class<?>>();
		resources.add(io.swagger.jaxrs.listing.ApiListingResource.class);
		resources.add(io.swagger.jaxrs.listing.SwaggerSerializers.class);
		resources.add(WsValidacionRNECController.class);
		resources.add(ConstraintExceptionMapper.class);
		resources.add(BusinessExceptionMapper.class);
		resources.add(InternalExcpetionMapper.class);
		resources.add(JacksonJsonProvider.class);
		return resources;
	}
}
