package com.porvenir.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.porvenir.commons.ConstantesRNEC;
import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.SearchProperties;
import com.porvenir.dto.ReqRNEC;
import com.porvenir.dto.RespRNEC;
import com.porvenir.exception.HeaderValidateService;
import com.porvenir.exception.RespException;
import com.porvenir.facade.ValidaHuellaRNECFacadeLocal;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ResponseHeader;

/**
 * WsValidacionRENECController Controlador del servicio consulta
 * HUellas RNEC
 * 
 * @author William Castelblanco
 * @version 1.0
 * @since 03/02/2020
 */
@Api()
@Path("/v1")
public class WsValidacionRNECController { 
	private ValidaHuellaRNECFacadeLocal validaHuellaRNECFacade;
	@Context
	private HttpServletRequest request;
	
	/**
	 * Constante con el valor JDNI del EJB
	 */
	public static String EJB_INITIAL = "java:comp/env/ejb/ValidaHuellaRNECFacade";

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "OK -> Respuesta Exitosa", response = RespRNEC.class, responseHeaders = {
					@ResponseHeader(name = "rqUID", description = "Identificador unico del mensaje.", response = String.class) }),
			@ApiResponse(code = 406, message = "NOT ACCEPTABLE -> Errores de Negocio", response = RespException.class, responseHeaders = {
					@ResponseHeader(name = "rqUID", description = "Identificador unico del mensaje.", response = String.class) }),
			@ApiResponse(code = 500, message = "INTERNAL SERVER ERROR -> Errores Internos o no controlados", response = RespException.class, responseHeaders = {
					@ResponseHeader(name = "rqUID", description = "Identificador unico del mensaje.", response = String.class) }) })

	@ApiOperation(value = "Valida las huellas del cliente en Registraduria", response = ReqRNEC.class, tags = {
			"Validacion Huella RNEC", })

	@POST
	@Path(value = "/Validar")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response validarHuella(
			@ApiParam(value = "Identificador de la entidad que consume el servicio", required = true, defaultValue = "Long. Maxima: 15") @HeaderParam(value = "clientID") String clientID,
			@ApiParam(value = "Identificador unico del mensaje", required = true, defaultValue = "Long. Maxima: 36") @HeaderParam(value = "rqUID") String rqUID,
			@ApiParam(value = "Identificador del servicio y operacion", required = true, defaultValue = "Long. 11") @HeaderParam(value = "serviceID") String serviceID,
			@ApiParam(value = "Corresponde al nombre de usuario que hizo el Login en la App", required = true, defaultValue = "Long. Maxima:30") @HeaderParam(value = "userTransaction") String userTransaction,
			@Valid @ApiParam(value = "") ReqRNEC reqRNEC) throws Exception {

		Response response = null;
		RespRNEC respRNEC = null;
		Map<String, String> headerRequest = new HashMap<String, String>();
		SearchProperties.destroyInstance();
		SearchProperties searchProperties = SearchProperties.getInstance();
		final String uuid = UUID.randomUUID().toString();

		request.getSession().setAttribute("transactionId", uuid);
		headerRequest.put("transactionId", uuid);

		if (clientID != null) {
			headerRequest.put("clientID", clientID);
		}
		if (rqUID != null) {
			headerRequest.put("rqUID", rqUID);
		}
		if (serviceID != null) {
			headerRequest.put("serviceID", serviceID);
		}
		if (userTransaction != null) {
			headerRequest.put("userTransaction", userTransaction);
		}
		HeaderValidateService.validateRequiredHeader(
				searchProperties.searchParam(ConstantesRNEC.HEADERS_REQUEST_REQUIRED), headerRequest);

		validaHuellaRNECFacade = (ValidaHuellaRNECFacadeLocal) Comunes.getEJB(EJB_INITIAL);
		
		respRNEC = validaHuellaRNECFacade.validHuellaIdentity(reqRNEC, headerRequest);	
		
		if(respRNEC.getStatus().getStatusCode() == ConstantesService.COD_RESPUESTA_200)
		{
			response = Comunes.headerResponse(rqUID, Status.OK, respRNEC);
		}
		else
		{
			response = Comunes.headerResponse(rqUID, Status.NOT_ACCEPTABLE, respRNEC);
		}
		
		clientID = null;
		headerRequest = null;
		reqRNEC = null;
		respRNEC = null;
		rqUID = null;
		SearchProperties.destroyInstance();
		searchProperties = null;
		serviceID = null;
		userTransaction = null;
		return response;
	}
}