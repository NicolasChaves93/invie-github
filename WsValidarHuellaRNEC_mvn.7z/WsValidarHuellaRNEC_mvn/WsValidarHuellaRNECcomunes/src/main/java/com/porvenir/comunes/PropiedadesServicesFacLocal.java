package com.porvenir.comunes;

import java.util.Map;

import javax.ejb.Local;

/**
 * Interfaz local para la busqueda de las propiedades
 * 
 * @author Harry Hurtado Arango POR09785
 * @since 1-11-2019
 */
@Local
public interface PropiedadesServicesFacLocal {
	/**
	 * Buscar propiedades
	 * @param serviceId: identificacion unico del servicio
	 * @return Map con la informacion descriptiva del servicio
	 */
	public Map<String, String> findAllPropertiesByServicesId(String serviceId);
}
