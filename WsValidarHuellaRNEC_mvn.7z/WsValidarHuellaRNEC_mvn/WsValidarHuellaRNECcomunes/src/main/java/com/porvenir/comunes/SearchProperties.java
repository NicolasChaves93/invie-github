package com.porvenir.comunes;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.ws.rs.WebApplicationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Clase que busca el archivo properties dentro del proyecto
 * 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 18/10/2019
 */
public class SearchProperties 
{
	private Properties prop = null;
	private static SearchProperties search = null;
	private Map<String,String> mapValuesBD=new HashMap<String, String>();

	private SearchProperties() 
	{
		String NAME_FILE_PROPERTIES = "configuracion.properties";

		prop = new Properties();
		InputStream is = null;

		try 
		{
			is = getClass().getClassLoader().getResourceAsStream(NAME_FILE_PROPERTIES);
			prop.load(is);
		}
		catch (IOException e) 
		{
			
		}
		
		//Obtiene las propiedades 
		PropiedadesServicesFacLocal propertiesEJB=(PropiedadesServicesFacLocal)Comunes.getEJB(ConstantesService.EJB_PROPERTIES);
		if(propertiesEJB!=null)
		{
			Map<String,String> mapValuesBDTmp =propertiesEJB.findAllPropertiesByServicesId(prop.getProperty(ConstantesService.SERVICE_ID_NAME));
			if(!mapValuesBDTmp.isEmpty())
			{
				mapValuesBD.putAll(mapValuesBDTmp);
			}
		}
		is = null;
		propertiesEJB = null;
	}

	/**
	 * Instanciar la clase SearchProperties
	 * 
	 * @return SearchProperties
	 */
	public static SearchProperties getInstance()
	{
		if (search == null) 
		{
			search = new SearchProperties();
		}
		return search;
	}

	/**
	 * Metodo que reinicia la instancia
	 */
	public static void destroyInstance() 
	{
		search = null;
	}

	/**
	 * Metodo para buscar en el archivo properties local
	 * 
	 * @param param
	 *            Nombre del parametro
	 * @return valor de la propiedad
	 */
	public String searchParam(String param) {
		String respuesta = "";
		
		// Valida en el archivo local si esta la propiedad
		if (prop != null) {
			respuesta = prop.getProperty(param);
		} else {
			throw new WebApplicationException("Por favor verificar que el archivo de properties sea el correcto");
		}
		
		// Si la propiedad local no se encuentra la busca en la base de datos
		if(respuesta==null){
			respuesta=mapValuesBD.get(param);
		}
		param = null;
		return respuesta;
	}

}
