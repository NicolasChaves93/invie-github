package com.porvenir.exception;

/**
 * Objeto para capturar las excepciones de negocio
 * 
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 18/10/2019
 */
public class BusinessException extends Exception {
 
	private static final long serialVersionUID = 1L;
	private int codigo;
	private String descripcion;
	private String messageCause;

	public BusinessException(int codigo, String descripcion, String messageCause) {
		super(descripcion);
		this.codigo = codigo;
		this.descripcion = descripcion;
		this.messageCause = messageCause;
	}

	public BusinessException(int codigo, String descripcion) {
		super(descripcion);
		this.codigo = codigo;
		this.descripcion = descripcion;
	}

	/**
	 * getCodigo: Metodo para obtener el valor de la variable codigo
	 * @return codigo
	 */
	public int getCodigo() {
		return codigo;
	}

	/**
	 * setCodigo: Metodo para guardar informacion en la variable codigo
	 * @param codigo
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMessageCause() {
		return messageCause;
	}

	public void setMessageCause(String messageCause) {
		this.messageCause = messageCause;
	}

}
