package com.porvenir.exception;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.SearchProperties;

/**
 * Clase donde se implementa el loger para mapear los errores de negocio
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 18/10/2019
 */
@Provider
public class BusinessExceptionMapper implements ExceptionMapper<BusinessException> { 
	@Context
	private HttpServletRequest request;

	@Override
	public Response toResponse(BusinessException exception) {
		RespException resp = new RespException();
		RespStatus status = new RespStatus();
		Response response = null;
		
		status.setStatusCode(exception.getCodigo());
		status.setStatusDesc(exception.getDescripcion());
		resp.setStatus(status);
		response = Comunes.headerResponse(request.getHeader("rqUID"), Status.NOT_ACCEPTABLE, resp);

		exception = null;
		resp = null;
		status = null;
		return response;
	}

}
