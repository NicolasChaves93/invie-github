package com.porvenir.exception;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.SearchProperties;

@Provider
public class ConstraintExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

	@Context
	private HttpServletRequest request;

	public Response toResponse(ConstraintViolationException exception) 
	{
		RespException resp = new RespException();
		RespStatus status = new RespStatus();
		Response response;
		SearchProperties searchProperties = SearchProperties.getInstance();

		status.setStatusCode(ConstantesService.COD_ERROR_106);//(Status.NOT_ACCEPTABLE.getStatusCode());
		final List<String> listMessagesResp = new ArrayList<String>();
		exception.getConstraintViolations().forEach(element -> {
			StringBuilder messageCompleted = new StringBuilder();

			messageCompleted.append(element.getPropertyPath()).append("->").append(element.getMessage());
			listMessagesResp.add(messageCompleted.toString());
		});

		status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_106_MESSAGE) + listMessagesResp.toString());
		resp.setStatus(status);
		response = Comunes.headerResponse(request.getHeader("rqUID"), Status.NOT_ACCEPTABLE, resp);
		
		exception = null;
		SearchProperties.destroyInstance();
		searchProperties = null;
		resp = null;
		status = null;
		return response;
	}

}
