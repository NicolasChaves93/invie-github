package com.porvenir.exception;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.SearchProperties;

public class HeaderValidateService 
{ 
	
	/**
	 * Valida que la peticion tenga las cabeceras requeridas
	 * @param requeredHeaders Cabeceras requeridas
	 * @param headers Cabeceras Http
	 * @throws BusinessException Expecion regla de negocio
	 */
	public static void validateRequiredHeader(String requeredHeaders, final Map<String, String> headers)
			throws BusinessException 
	{

		HeadServicesDTO[] headPropertiesTmp;
		List<HeadServicesDTO> headProperties = null;
		final StringBuilder headersNotPresent = new StringBuilder();
		final StringBuilder headersNotlengthapproved = new StringBuilder();
		SearchProperties searchProperties = SearchProperties.getInstance();

		try 
		{
			// Convierte propiedades de la cabecera Json a Objeto
			headPropertiesTmp = (HeadServicesDTO[]) Comunes.convertJSONTOObject(requeredHeaders,
					HeadServicesDTO[].class);
			headProperties = Arrays.asList(headPropertiesTmp);
		}
		catch (IOException ex) 
		{
			headProperties = null;
			headPropertiesTmp = null;
			throw new BusinessException(ConstantesService.COD_ERROR_101,
					searchProperties.searchParam("" + ConstantesService.COD_ERROR_101_MESSAGE), "" + ex);
		}

		long count = headProperties.stream().filter(new Predicate<HeadServicesDTO>() {
			int countHeaderPresent = 0;
			int countHeaderValidateSize = 0;

			public boolean test(HeadServicesDTO element) 
			{
				if ((headers.containsKey(element.getHeaderName()))) 
				{
					boolean responseEval = evaluateHeaders(countHeaderValidateSize, headers, element,
							headersNotlengthapproved, headers.get(element.getHeaderName()));
					if (responseEval) 
					{
						countHeaderValidateSize++;
					}
					return responseEval;
				}
				else 
				{
					boolean responseEval = evaluateHeadersNotPresent(countHeaderPresent, element, headersNotPresent);
					if (responseEval) 
					{
						countHeaderPresent++;
					}
					return responseEval;
				}
			}
		}).count();

		boolean errorPresent = count != 0;

		if (errorPresent) 
		{
			StringBuilder headersResults = new StringBuilder();
			if (headersNotPresent.length() != 0) 
			{
				headersResults.append(headersNotPresent.toString());
			}
			if (headersNotlengthapproved.length() != 0) 
			{
				headersResults.append(headersNotlengthapproved.toString());
			}
			headProperties = null;
			headPropertiesTmp = null;
			requeredHeaders = null;
			throw new BusinessException(ConstantesService.COD_ERROR_100,
					searchProperties.searchParam(ConstantesService.COD_ERROR_100_MESSAGE).concat(" "+headersResults.toString()));
		}
	}

	/**
	 * Metodo que me muestra cuales headers obligatorios no se enviaron en la peticion
	 * @param countSize numero de headers detectados
	 * @param element elemento header
	 * @param messages Mensaje del error
	 * @return true si la operacion es correcta
	 */
	private static boolean evaluateHeadersNotPresent(int countSize, HeadServicesDTO element, StringBuilder messages) {
		if (element.getRequired().equals(true)) {
			if (countSize == 0) {
				messages.append(element.getHeaderName());
			} else {
				messages.append(",".concat(element.getHeaderName())).append(" ");
			}
			element = null;
			messages = null;
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Metodo que me valida si la logitud del header y el parametro enviado es correcto
	 * @param countSize numero de headers detectados
	 * @param headers llave valor de la informacion de los headers
	 * @param element elemento header
	 * @param messages Mensaje del error
	 * @param dataToEval informacion con los header que se deben evaluar
	 * @returntrue si la operacion es correcta
	 */
	private static boolean evaluateHeaders(int countSize, Map<String, String> headers, HeadServicesDTO element,
			StringBuilder messages, String dataToEval) {
		Integer headerTam = headers.get(element.getHeaderName()).length();
		boolean responseEval = false;
		// Evalua los datos tipo Enum
		if (element.getEnumData() != null && isPresentValueEnumHeader(element.getEnumData(), dataToEval) == false) {
			messages.append(element.getHeaderName());
			messages.append(" Validacion tipo enum -> solo se aceptan los siguientes datos");
			int countElement = 0;
			messages.append("[");
			for (String data : element.getEnumData()) {
				if (countElement == 0) {
					messages.append(data);
				} else {
					messages.append(",");
					messages.append(data);
				}
				countElement++;
			}
			messages.append("]");

			responseEval = true;

			// Valida si la longitud es correcta
		} else if ((headerTam < element.getMin()) || (headerTam > element.getMax())) {
			if (countSize == 0) {
				messages.append("Validacion por Longitud => ");
			}
			messages.append(",".concat(element.getHeaderName()).concat("(").concat(element.getMin().toString())
					.concat(" - ").concat(element.getMax().toString()).concat(")"));
			responseEval = true;
		} else {
			responseEval = false;
		}
		dataToEval = null;
		element = null;
		headers = null;
		headerTam = null;
		messages = null;
		return responseEval;
	}

	/**
	 * Metodo para validar que los valores ingresados sean correctos dentro de los parametrizados en el enum
	 * @param enumData valores del enum
	 * @param dataToEval parametro a evaluar
	 * @return
	 */
	private static boolean isPresentValueEnumHeader(String[] enumData, String dataToEval) {
		boolean isPresent = false;
		if (enumData != null) {
			List<String> listTmp = Arrays.asList(enumData);
			Optional<String> resultEval = listTmp.stream().filter(p -> p.equals(dataToEval)).findFirst();
			isPresent = resultEval.isPresent();
		}
		enumData = null;
		return isPresent;
	}
}
