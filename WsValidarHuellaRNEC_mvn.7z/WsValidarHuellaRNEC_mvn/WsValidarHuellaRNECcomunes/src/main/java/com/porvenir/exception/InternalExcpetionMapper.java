package com.porvenir.exception;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.porvenir.comunes.Comunes;
import com.porvenir.comunes.ConstantesService;
import com.porvenir.comunes.SearchProperties;

/**
 * Clase para mapear los errores internos del servicio
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 25/10/2019
 */
@Provider
public class InternalExcpetionMapper implements ExceptionMapper<Throwable> { 
	@Context
	private HttpServletRequest request;

	@Override
	public Response toResponse(Throwable exception) {
		RespException resp = new RespException();
		RespStatus status = new RespStatus();
		SearchProperties searchProperties = SearchProperties.getInstance();
		Response response;

		status.setStatusCode(ConstantesService.COD_ERROR_500);
		status.setStatusDesc(searchProperties.searchParam(ConstantesService.COD_ERROR_500_MESSAGE));
		resp.setStatus(status);
		response = Comunes.headerResponse(request.getHeader("rqUID"), Status.INTERNAL_SERVER_ERROR, resp);

		exception = null;
		resp = null;
		status = null;
		SearchProperties.destroyInstance();
		searchProperties = null;
		
		return response;
	}

}
