package com.porvenir.exception;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto para las exepciones del servicio
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 18/10/2019
 */
public class RespException { 

	@JsonProperty("status")
	@ApiModelProperty(value = "Objeto con el estado de la respuesta servicio")
	private RespStatus status;

	public RespStatus getStatus() {
		return status;
	}

	public void setStatus(RespStatus status) {
		this.status = status;
	}
}
