package com.porvenir.exception;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Objeto para las exepciones del servicio
 * @author Bryan Nicolas Chaves Arce (POR09785)
 * @version 1.0
 * @since 18/10/2019
 */
public class RespStatus 
{ 

	@JsonProperty("statusCode")
	@ApiModelProperty(value = "Codigo de la respuesta del servicio")
	private int statusCode;

	@JsonProperty("statusDesc")
	@ApiModelProperty(value = "Descripción de la respuesta del servicio")
	private String statusDesc;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
}
