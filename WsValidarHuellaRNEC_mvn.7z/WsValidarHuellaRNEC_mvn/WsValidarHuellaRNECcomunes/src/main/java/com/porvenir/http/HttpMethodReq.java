package com.porvenir.http;

import com.fasterxml.jackson.annotation.JsonValue;

public enum HttpMethodReq {

	GET("GET"),POST("POST"),PUT("PUT"),DELETE("DELETE");
	private  String value;
	 HttpMethodReq(String value){
		this.value=value;
	}
	 
	 @JsonValue
		public String toString() {
			return String.valueOf(value);
		}
}
