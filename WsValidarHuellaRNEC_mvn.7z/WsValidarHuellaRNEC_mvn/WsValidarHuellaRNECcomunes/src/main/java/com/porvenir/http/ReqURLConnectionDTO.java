package com.porvenir.http;

import java.util.Map;

/**
 * Recibe los parametros para realizar la peticion por URL
 * 
 * @author Harry Hurtado POR09786
 *
 */
public class ReqURLConnectionDTO {
	private final String UrlReq;
	private final String body;
	private final HttpMethodReq httpMethodReq;
	private final Map<String, String> headers;
	private final String contentTypeConsume;
	private Integer timeOut;

	public ReqURLConnectionDTO(String urlReq, String body, HttpMethodReq httpMethodReq, Map<String, String> headers,
			String contentTypeProduce) {
		super();
		UrlReq = urlReq;
		this.body = body;
		this.httpMethodReq = httpMethodReq;
		this.headers = headers;
		this.contentTypeConsume = contentTypeProduce;
	}

	public String getUrlReq() {
		return UrlReq;
	}

	public String getBody() {
		return body;
	}

	public HttpMethodReq getHttpMethodReq() {
		return httpMethodReq;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public String getContentTypeConsume() {
		return contentTypeConsume;
	}

	public Integer getTimeOut() {
		return timeOut;
	}

	public void setTimeOut(Integer timeOut) {
		this.timeOut = timeOut;
	}

}
