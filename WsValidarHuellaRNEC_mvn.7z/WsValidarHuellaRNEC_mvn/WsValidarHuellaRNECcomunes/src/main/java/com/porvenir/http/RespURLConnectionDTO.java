package com.porvenir.http;

import java.util.List;
import java.util.Map;

/**
 * Contiene la respuesta generado al realizar la peticion o http/https
 * @author Harry Hurtado POR09786
 *
 */
public class RespURLConnectionDTO {
	private final Map<String, List<String>> headersResp;
	private final String bodyResp;
	private final int httpStatus;
	private final String respContentType;
	
	public RespURLConnectionDTO(Map<String, List<String>> headersResp, String bodyResp, int httpStatus,
			String responseProduce) {
		super();
		this.headersResp = headersResp;
		this.bodyResp = bodyResp;
		this.httpStatus = httpStatus;
		this.respContentType = responseProduce;
	}
	public Map<String, List<String>> getHeadersResp() {
		return headersResp;
	}
	public String getBodyResp() {
		return bodyResp;
	}
	public int getHttpStatus() {
		return httpStatus;
	}
	public String getRespContentType() {
		return respContentType;
	}

	
	
	
}
